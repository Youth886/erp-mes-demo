import {
  createRouter,
  createWebHistory,
  createWebHashHistory,
} from 'vue-router'

import DashboardView from '../views/DashboardView.vue'
import ProductView from '../views/ProductView.vue'
import CustomerView from '../views/CustomerView.vue'
import SalesOrderView from '../views/SalesOrderView.vue'
import InventoryView from '../views/InventoryView.vue'
import BomView from '../views/BomView.vue'
import RoutingView from '../views/RoutingView.vue'
import ManufacturingOrderView from '../views/ManufacturingOrderView.vue'
import MesView from '../views/MesView.vue'
import InventoryTransactionView from '../views/InventoryTransactionView.vue'
import WarehouseView from '../views/WarehouseView.vue'
import BusinessFlowView from '../views/BusinessFlowView.vue'

const router = createRouter({
  history: import.meta.env.MODE === 'demo' ? createWebHashHistory() : createWebHistory(),

  routes: [
    { path: '/business-flow', component: BusinessFlowView },
    { path: '/warehouses', component: WarehouseView },
    { path: '/inventory-transactions', component: InventoryTransactionView },
    {
      path: '/',
      component: DashboardView,
    },
    {
      path: '/products',
      component: ProductView,
    },
    {
      path: '/customers',
      component: CustomerView,
    },
    {
      path: '/sales-orders',
      component: SalesOrderView,
    },
    {
      path: '/inventory',
      component: InventoryView,
    },
    {
      path: '/boms',
      component: BomView,
    },
    {
      path: '/routings',
      component: RoutingView,
    },
    {
      path: '/manufacturing-orders',
      component: ManufacturingOrderView,
    },
    {
      path: '/mes',
      component: MesView,
    },
  ],
})

export default router
