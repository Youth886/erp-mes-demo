import axios from 'axios'
import { demoAdapter } from '../demo/adapter'
import { demoMode } from '../demo/engine'

const api = axios.create({
  baseURL: demoMode ? undefined : 'http://127.0.0.1:8000',
  adapter: demoMode ? demoAdapter : undefined,
  timeout: 10000,
})

export default api
