import { AxiosError, AxiosHeaders, type AxiosAdapter } from 'axios'
import { demoRequest } from './engine'

/** 通过本地业务处理器响应原页面接口，演示模式不发送后端请求。 */
export const demoAdapter: AxiosAdapter = async config => {
  try {
    const body = typeof config.data === 'string' ? JSON.parse(config.data) : config.data ?? {}
    return { config, status: 200, statusText: 'OK', headers: new AxiosHeaders(), data: demoRequest(config.method ?? 'get', config.url ?? '/', body, config.params ?? {}) }
  } catch (cause) {
    const message = cause instanceof Error ? cause.message : '演示操作失败'
    throw new AxiosError(message, 'ERR_BAD_REQUEST', config, undefined, { config, status: 400, statusText: 'Demo validation', headers: new AxiosHeaders(), data: { detail: message } })
  }
}
