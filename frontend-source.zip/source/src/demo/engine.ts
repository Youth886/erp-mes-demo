import snapshot from './snapshot.json'

// 各页面接口有不同字段，演示存储统一保留原接口对象结构。
type Row = Record<string, any>
type State = Record<string, Row[]>
const clone = <T>(value: T): T => structuredClone(value)
const now = () => new Date().toISOString()
const round = (value: number) => Math.round(value * 1000) / 1000
const ensure = (condition: unknown, message: string): void => { if (!condition) throw new Error(message) }
const required = (rows: Row[], id: unknown): Row => { const row = rows.find(r => r.id === Number(id)); ensure(row, '关联记录不存在'); return row! }
const positive = (value: unknown): number => { const n = Number(value); ensure(Number.isFinite(n) && n > 0, '数量必须大于零'); return round(n) }
export const demoMode = import.meta.env.MODE === 'demo'
const storageKey = () => `erp-demo-v1:${location.pathname}`
/** 只恢复本网站的演示记录，失败时仍可浏览初始数据。 */
function readState(): State {
  try {
    const raw = localStorage.getItem(storageKey()), parsed = raw ? JSON.parse(raw) : null
    if (parsed && Object.keys(snapshot).every(key => Array.isArray(parsed[key]))) return parsed
  } catch { /* 浏览器禁止存储时，初始页面仍可正常打开。 */ }
  return clone(snapshot)
}
let state: State | undefined
export function resetDemo(): void { localStorage.removeItem(storageKey()); state = clone(snapshot) }
/** 在副本上办理业务，保存成功后整体替换；出错不留下半笔操作。 */
export function demoRequest(method: string, path: string, body: Row = {}, params: Row = {}): unknown {
  const db = clone(state ?? (state = readState()))
  const list = (key: string): Row[] => db[key] ?? (db[key] = [])
  const add = (key: string, data: Row): Row => { const row = { ...data, id: Math.max(0, ...list(key).map(r => r.id)) + 1 }; list(key).push(row); return row }
  const active = (key: string, id: unknown): Row => { const row = required(list(key), id); ensure(row.active, '该基础资料已停用'); return row }
  const stock = (warehouse: number, product: number): Row => list('inventory').find(r => r.warehouse_id === warehouse && r.product_id === product)
    ?? add('inventory', { warehouse_id: warehouse, product_id: product, on_hand_quantity: 0, reserved_quantity: 0, available_quantity: 0 })
  const available = (s: Row): number => Math.max(0, round(Number(s.on_hand_quantity) - Number(s.reserved_quantity)))
  const reserved = (id: number): number => list('inventory/reservations').filter(r => r.sales_order_item_id === id).reduce((n, r) => n + Number(r.quantity), 0)
  const reserve = (order: Row, item: Row, warehouse: number, amount: number): void => {
    if (amount <= 0) return
    const s = stock(warehouse, item.product_id); s.reserved_quantity = round(Number(s.reserved_quantity) + amount); s.available_quantity = available(s)
    add('inventory/reservations', { sales_order_id: order.id, sales_order_item_id: item.id, warehouse_id: warehouse, product_id: item.product_id, quantity: amount, created_at: now() })
  }
  const lines = (order: Row): Row[] => order.items.map((item: Row) => {
    const mo = list('manufacturing-orders').find(r => r.source_sales_order_item_id === item.id)
    return { sales_order_item_id: item.id, product_id: item.product_id, requested_quantity: item.quantity, reserved_quantity: reserved(item.id), shortage_quantity: Math.max(0, round(Number(item.quantity) - reserved(item.id))), manufacturing_order_id: mo?.id ?? null, manufacturing_order_no: mo?.order_no ?? null, manufacturing_order_status: mo?.status ?? null }
  })
  const match = path.split('/').filter(Boolean), group = match[0]!, id = Number(match[1]), action = match[2]
  let result: unknown
  if (method === 'get') {
    if (Object.hasOwn(db, path.slice(1))) return clone(list(path.slice(1)))
    if (group === 'sales-orders') { const order = required(list(group), id); return action === 'allocation-summary' ? { order_id: id, order_no: order.order_no, status: order.status, lines: lines(order) } : clone(order) }
    if (group === 'products') { const product = required(list(group), id); return clone(action ? list(action === 'bom' ? 'boms' : 'routings').find(r => r.product_id === product.id && r.active) ?? (() => { throw new Error('该产品尚未配置对应资料') })() : product) }
    if (group === 'manufacturing-operations' && action === 'reports') return clone(list('reports').filter(r => r.operation_id === id))
    if (group === 'manufacturing-orders') {
      const mo = required(list(group), id)
      if (action === 'operations') return clone(list('operations').filter(r => r.manufacturing_order_id === id).sort((a, b) => a.sequence - b.sequence))
      if (action === 'material-requirements') {
        const bom = list('boms').find(r => r.product_id === mo.product_id && r.active); ensure(bom, '该产品尚未配置有效 BOM')
        active('warehouses', params.warehouse_id)
        return { manufacturing_order_id: id, manufacturing_order_no: mo.order_no, product_id: mo.product_id, planned_quantity: mo.planned_quantity, bom_id: bom!.id, bom_name: bom!.name, warehouse_id: Number(params.warehouse_id), lines: bom!.items.map((item: Row) => {
          const s = stock(Number(params.warehouse_id), item.component_product_id), need = round(Number(item.quantity) * Number(mo.planned_quantity))
          return { component_product_id: item.component_product_id, unit_quantity: item.quantity, required_quantity: need, ...s, shortage_quantity: Math.max(0, round(need - available(s))) }
        }) }
      }
      return clone(mo)
    }
    throw new Error('此演示未提供该查询')
  }
  if (['products', 'customers', 'warehouses', 'boms', 'routings'].includes(group)) {
    if (method === 'patch') { const row = required(list(group), id); row.active = action === 'activate'; result = row }
    else {
      ensure(String(body.name ?? '').trim(), '请填写名称')
      if (['products', 'customers', 'warehouses'].includes(group)) { ensure(String(body.code ?? '').trim(), '请填写编码'); ensure(!list(group).some(r => r.code === body.code && r.id !== id), '编码已经存在') }
      if (group === 'boms' || group === 'routings') {
        active('products', body.product_id); ensure(!list(group).some(r => r.product_id === body.product_id && r.active), '该产品已有有效配置')
        const children = group === 'boms' ? body.items : body.operations; ensure(children?.length, '请至少填写一条明细')
        if (group === 'boms') children.forEach((r: Row) => { active('products', r.component_product_id); positive(r.quantity); ensure(r.component_product_id !== body.product_id, '产品不能作为自身物料') })
        else ensure(new Set(children.map((r: Row) => r.sequence)).size === children.length && children.every((r: Row) => r.sequence > 0 && r.operation_name?.trim()), '工序序号须为不重复的正数，名称不能为空')
      }
      result = method === 'put' ? Object.assign(required(list(group), id), body) : add(group, { active: true, ...body })
    }
  } else if (group === 'sales-orders') {
    if (method === 'post' && !match[1]) {
      active('customers', body.customer_id); ensure(body.order_no?.trim() && !list(group).some(r => r.order_no === body.order_no), '订单号不能为空或重复'); ensure(body.items?.length, '请添加订单明细')
      let itemId = Math.max(0, ...list(group).flatMap(r => r.items.map((item: Row) => item.id)))
      const items = body.items.map((item: Row) => { active('products', item.product_id); ensure(Number.isFinite(Number(item.unit_price)) && Number(item.unit_price) >= 0, '单价不能为负数'); return { ...item, id: ++itemId, quantity: positive(item.quantity) } })
      result = add(group, { ...body, items, status: 'draft', created_at: now(), total_amount: Math.round(items.reduce((sum: number, item: Row) => sum + item.quantity * item.unit_price, 0) * 100) / 100 })
    } else {
      const order = required(list(group), id)
      if (action === 'confirm') {
        ensure(order.status === 'draft', '只有草稿订单可以确认'); active('customers', order.customer_id); active('warehouses', body.warehouse_id)
        order.items.forEach((item: Row) => { active('products', item.product_id); reserve(order, item, body.warehouse_id, Math.min(Number(item.quantity), available(stock(body.warehouse_id, item.product_id)))) })
        order.status = 'confirmed'; result = { order_id: id, order_no: order.order_no, status: order.status, warehouse_id: body.warehouse_id, lines: lines(order) }
      } else if (action === 'manufacturing-orders') {
        ensure(order.status === 'confirmed', '请先确认销售订单')
        result = lines(order).filter(r => r.shortage_quantity > 0 && !r.manufacturing_order_id).map(r => add('manufacturing-orders', { order_no: `MO-${String(id).padStart(4, '0')}-${String(r.sales_order_item_id).padStart(4, '0')}`, product_id: r.product_id, planned_quantity: r.shortage_quantity, source_sales_order_id: id, source_sales_order_item_id: r.sales_order_item_id, status: 'planned', created_at: now() }))
        ensure((result as Row[]).length, '没有生产缺口，或生产订单已生成')
      } else throw new Error('不支持的销售操作')
    }
  } else if (group === 'manufacturing-orders') {
    const mo = required(list(group), id)
    if (action === 'release') {
      ensure(mo.status === 'planned', '只有待下达订单可以下达'); const routing = list('routings').find(r => r.product_id === mo.product_id && r.active)
      ensure(routing?.operations?.length, '请先配置有效工艺路线')
      routing!.operations.forEach((op: Row) => add('operations', { manufacturing_order_id: id, sequence: op.sequence, name: op.operation_name, planned_quantity: mo.planned_quantity, completed_quantity: 0, status: 'pending' }))
      mo.status = 'released'; result = mo
    } else if (action === 'receive') {
      ensure(mo.status === 'completed', '只有已完成订单可以入库'); active('warehouses', body.warehouse_id)
      const s = stock(body.warehouse_id, mo.product_id), amount = Number(mo.planned_quantity), order = required(list('sales-orders'), mo.source_sales_order_id)
      const item = required(order.items, mo.source_sales_order_item_id), auto = Math.min(amount, Math.max(0, Number(item.quantity) - reserved(item.id)))
      s.on_hand_quantity = round(Number(s.on_hand_quantity) + amount); reserve(order, item, body.warehouse_id, auto); s.available_quantity = available(s); mo.status = 'received'
      add('inventory/transactions', { warehouse_id: body.warehouse_id, product_id: mo.product_id, transaction_type: 'production_receipt', quantity: amount, reference_type: 'manufacturing_order', reference_id: id, created_at: now() })
      result = { ...s, manufacturing_order_id: id, received_quantity: amount, auto_reserved_quantity: auto, manufacturing_order_status: mo.status }
    } else throw new Error('不支持的生产操作')
  } else if (group === 'manufacturing-operations' && action === 'reports') {
    const op = required(list('operations'), id), mo = required(list('manufacturing-orders'), op.manufacturing_order_id), good = positive(body.good_quantity)
    ensure(['released', 'in_progress'].includes(mo.status) && op.status !== 'completed', '当前状态不能报工')
    ensure(!list('operations').some(r => r.manufacturing_order_id === mo.id && r.sequence < op.sequence && r.status !== 'completed'), '请先完成前面的工序')
    ensure(body.operator_name?.trim() && Number.isFinite(Number(body.defect_quantity)) && Number(body.defect_quantity) >= 0, '请填写操作员与有效不良数量'); ensure(good <= round(Number(op.planned_quantity) - Number(op.completed_quantity)), '合格数量超过剩余数量')
    add('reports', { ...body, operation_id: id, created_at: now() }); op.completed_quantity = round(Number(op.completed_quantity) + good); op.status = op.completed_quantity >= Number(op.planned_quantity) ? 'completed' : 'in_progress'
    mo.status = list('operations').filter(r => r.manufacturing_order_id === mo.id).every(r => r.status === 'completed') ? 'completed' : 'in_progress'; result = { operation_status: op.status, manufacturing_order_status: mo.status }
  } else if (path === '/inventory/receipts') {
    active('warehouses', body.warehouse_id); active('products', body.product_id); const amount = positive(body.quantity), s = stock(body.warehouse_id, body.product_id)
    const receiptId = Math.max(0, ...list('inventory/transactions').filter(r => r.reference_type === 'inventory_receipt').map(r => r.reference_id)) + 1
    s.on_hand_quantity = round(Number(s.on_hand_quantity) + amount); s.available_quantity = available(s)
    add('inventory/transactions', { ...body, transaction_type: 'other_receipt', reference_type: 'inventory_receipt', reference_id: receiptId, created_at: now() }); result = { ...s, receipt_id: receiptId, receipt_quantity: amount }
  } else throw new Error('该操作尚未包含在浏览器演示中')
  try { localStorage.setItem(storageKey(), JSON.stringify(db)) } catch { throw new Error('浏览器无法保存演示数据，请允许网站存储后重试；本次未保存') }
  state = db; return clone(result)
}
