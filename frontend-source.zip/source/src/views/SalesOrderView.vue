<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'

import {
  Delete,
  Plus,
  Refresh,
  View,
} from '@element-plus/icons-vue'

import {
  ElMessage,
  ElMessageBox,
} from 'element-plus'

import api from '../services/api'
const route = useRoute()

interface SalesOrderItem {
  id: number
  product_id: number
  quantity: number | string
  unit_price: number | string
}

interface SalesOrder {
  id: number
  order_no: string
  customer_id: number
  status: string
  created_at: string
  total_amount: number | string
  items: SalesOrderItem[]
}

interface Customer {
  id: number
  code: string
  name: string
  active: boolean
}

interface Product {
  id: number
  code: string
  name: string
  unit: string
  active: boolean
}

interface Warehouse {
  id: number
  code: string
  name: string
  active: boolean
}

interface AllocationLine {
  sales_order_item_id: number
  product_id: number
  requested_quantity: number | string
  reserved_quantity: number | string
  shortage_quantity: number | string
}

interface ConfirmResult {
  order_id: number
  order_no: string
  status: string
  warehouse_id: number
  lines: AllocationLine[]
}

interface AllocationSummaryLine {
  sales_order_item_id: number
  product_id: number
  requested_quantity: number | string
  reserved_quantity: number | string
  shortage_quantity: number | string
  manufacturing_order_id: number | null
  manufacturing_order_no: string | null
  manufacturing_order_status: string | null
}

interface AllocationSummary {
  order_id: number
  order_no: string
  status: string
  lines: AllocationSummaryLine[]
}

interface OrderFormLine {
  product_id: number | null
  quantity: number
  unit_price: number
}

type TagType =
  | 'success'
  | 'warning'
  | 'info'
  | 'primary'
  | 'danger'

const salesOrders = ref<SalesOrder[]>([])
const customers = ref<Customer[]>([])
const products = ref<Product[]>([])
const warehouses = ref<Warehouse[]>([])

const loading = ref(false)
const saving = ref(false)

/* =========================
   新增销售订单
   ========================= */

const createDialogVisible = ref(false)

const orderForm = ref({
  order_no: '',
  customer_id: null as number | null,
  items: [
    {
      product_id: null,
      quantity: 1,
      unit_price: 1,
    },
  ] as OrderFormLine[],
})

/* =========================
   确认订单
   ========================= */

const confirmDialogVisible = ref(false)

const confirmingOrder =
  ref<SalesOrder | null>(null)

const confirmWarehouseId =
  ref<number | null>(null)

/* =========================
   库存分配结果
   ========================= */

const confirmResult =
  ref<ConfirmResult | null>(null)

const confirmResultDialogVisible =
  ref(false)

/* =========================
   销售订单详情
   ========================= */

const detailDrawerVisible = ref(false)
const detailLoading = ref(false)

const detailOrder =
  ref<SalesOrder | null>(null)

const orderDetail =
  ref<AllocationSummary | null>(null)

/* =========================
   基础数据
   ========================= */

const activeCustomers = computed(
  () =>
    customers.value.filter(
      customer => customer.active
    )
)

const activeProducts = computed(
  () =>
    products.value.filter(
      product => product.active
    )
)

const activeWarehouses = computed(
  () =>
    warehouses.value.filter(
      warehouse => warehouse.active
    )
)

async function loadData() {
  loading.value = true

  try {
    const [
      salesOrderResponse,
      customerResponse,
      productResponse,
      warehouseResponse,
    ] = await Promise.all([
      api.get<SalesOrder[]>(
        '/sales-orders'
      ),

      api.get<Customer[]>(
        '/customers'
      ),

      api.get<Product[]>(
        '/products'
      ),

      api.get<Warehouse[]>(
        '/warehouses'
      ),
    ])

    salesOrders.value =
      salesOrderResponse.data

    customers.value =
      customerResponse.data

    products.value =
      productResponse.data

    warehouses.value =
      warehouseResponse.data
  } catch (error) {
    console.error(error)

    ElMessage.error(
      '销售订单数据加载失败'
    )
  } finally {
    loading.value = false
  }
}

/* =========================
   新增销售订单
   ========================= */

function resetOrderForm() {
  orderForm.value = {
    order_no: '',
    customer_id: null,
    items: [
      {
        product_id: null,
        quantity: 1,
        unit_price: 1,
      },
    ],
  }
}

function openCreateDialog() {
  resetOrderForm()

  createDialogVisible.value = true
}

function addOrderItem() {
  orderForm.value.items.push({
    product_id: null,
    quantity: 1,
    unit_price: 1,
  })
}

function removeOrderItem(
  index: number
) {
  if (
    orderForm.value.items.length <= 1
  ) {
    ElMessage.warning(
      '销售订单至少需要一条产品明细'
    )

    return
  }

  orderForm.value.items.splice(
    index,
    1
  )
}

async function createSalesOrder() {
  if (
    !orderForm.value.order_no.trim()
  ) {
    ElMessage.warning(
      '请输入销售订单号'
    )

    return
  }

  if (
    orderForm.value.customer_id === null
  ) {
    ElMessage.warning(
      '请选择客户'
    )

    return
  }

  for (
    const item of orderForm.value.items
  ) {
    if (item.product_id === null) {
      ElMessage.warning(
        '请选择所有订单明细的产品'
      )

      return
    }

    if (item.quantity <= 0) {
      ElMessage.warning(
        '订单数量必须大于 0'
      )

      return
    }

    if (item.unit_price <= 0) {
      ElMessage.warning(
        '产品单价必须大于 0'
      )

      return
    }
  }

  saving.value = true

  try {
    await api.post(
      '/sales-orders',
      {
        order_no:
          orderForm.value.order_no.trim(),

        customer_id:
          orderForm.value.customer_id,

        items:
          orderForm.value.items.map(
            item => ({
              product_id:
                Number(item.product_id),

              quantity:
                item.quantity,

              unit_price:
                item.unit_price,
            })
          ),
      }
    )

    ElMessage.success(
      '销售订单创建成功'
    )

    createDialogVisible.value = false

    await loadData()
  } catch (error: any) {
    console.error(error)

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `创建失败：${detail}`
        : '销售订单创建失败'
    )
  } finally {
    saving.value = false
  }
}

/* =========================
   确认销售订单
   ========================= */

function openConfirmDialog(
  order: SalesOrder
) {
  confirmingOrder.value = order

  const firstWarehouse =
    activeWarehouses.value[0]

  confirmWarehouseId.value =
    firstWarehouse?.id ?? null

  confirmDialogVisible.value = true
}

async function confirmSalesOrder() {
  if (
    confirmingOrder.value === null
  ) {
    return
  }

  if (
    confirmWarehouseId.value === null
  ) {
    ElMessage.warning(
      '请选择库存分配仓库'
    )

    return
  }

  saving.value = true

  try {
    const response =
      await api.patch<ConfirmResult>(
        `/sales-orders/${confirmingOrder.value.id}/confirm`,
        {
          warehouse_id:
            confirmWarehouseId.value,
        }
      )

    confirmResult.value =
      response.data

    confirmDialogVisible.value = false

    confirmResultDialogVisible.value =
      true

    ElMessage.success(
      '销售订单确认成功'
    )

    await loadData()
  } catch (error: any) {
    console.error(error)

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `确认失败：${detail}`
        : '销售订单确认失败'
    )
  } finally {
    saving.value = false
  }
}

/* =========================
   生成生产订单
   ========================= */

async function generateManufacturingOrder(
  order: SalesOrder
) {
  try {
    await ElMessageBox.confirm(
      `确定根据销售订单“${order.order_no}”的当前生产缺口生成生产订单吗？`,
      '生成生产订单',
      {
        confirmButtonText: '确定生成',
        cancelButtonText: '取消',
        type: 'warning',
      }
    )
  } catch {
    return
  }

  saving.value = true

  try {
    await api.post(
      `/sales-orders/${order.id}/manufacturing-orders`
    )

    ElMessage.success(
      '生产订单生成成功'
    )

    await loadData()

    if (
      detailOrder.value?.id ===
      order.id
    ) {
      await loadOrderDetail(
        order
      )
    }
  } catch (error: any) {
    console.error(error)

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `生成失败：${detail}`
        : '生产订单生成失败'
    )
  } finally {
    saving.value = false
  }
}

/* =========================
   订单详情
   ========================= */

async function loadOrderDetail(
  order: SalesOrder
) {
  detailOrder.value = order
  detailDrawerVisible.value = true

  detailLoading.value = true

  try {
    const response =
      await api.get<AllocationSummary>(
        `/sales-orders/${order.id}/allocation-summary`
      )

    orderDetail.value =
      response.data
  } catch (error: any) {
    console.error(error)

    orderDetail.value = null

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `详情加载失败：${detail}`
        : '销售订单详情加载失败'
    )
  } finally {
    detailLoading.value = false
  }
}

function closeDetailDrawer() {
  detailDrawerVisible.value = false
  detailOrder.value = null
  orderDetail.value = null
}

/* =========================
   显示辅助函数
   ========================= */

function getCustomerName(
  customerId: number
) {
  const customer =
    customers.value.find(
      item => item.id === customerId
    )

  if (!customer) {
    return `客户 #${customerId}`
  }

  return `${customer.code} / ${customer.name}`
}

function getProductName(
  productId: number
) {
  const product =
    products.value.find(
      item => item.id === productId
    )

  if (!product) {
    return `产品 #${productId}`
  }

  return `${product.code} / ${product.name}`
}

function getWarehouseName(
  warehouseId: number
) {
  const warehouse =
    warehouses.value.find(
      item => item.id === warehouseId
    )

  if (!warehouse) {
    return `仓库 #${warehouseId}`
  }

  return `${warehouse.code} / ${warehouse.name}`
}

function getStatusText(
  status: string
) {
  const statusMap:
    Record<string, string> = {
      draft: '草稿',
      confirmed: '已确认',
    }

  return statusMap[status] ?? status
}

function getStatusType(
  status: string
): TagType {
  const statusMap:
    Record<string, TagType> = {
      draft: 'warning',
      confirmed: 'success',
    }

  return statusMap[status] ?? 'info'
}

function getManufacturingStatusText(
  status: string | null
) {
  if (!status) {
    return '-'
  }

  const statusMap:
    Record<string, string> = {
      planned: '计划中',
      released: '已下达',
      in_progress: '生产中',
      completed: '已完成',
      received: '已入库',
    }

  return statusMap[status] ?? status
}

function getManufacturingStatusType(
  status: string | null
): TagType {
  if (!status) {
    return 'info'
  }

  const statusMap:
    Record<string, TagType> = {
      planned: 'info',
      released: 'primary',
      in_progress: 'warning',
      completed: 'success',
      received: 'success',
    }

  return statusMap[status] ?? 'info'
}

function formatMoney(
  value: number | string
) {
  return Number(value).toFixed(2)
}

function formatDate(
  dateText: string
) {
  return new Date(
    dateText
  ).toLocaleString()
}

function formatQuantity(
  value: number | string
) {
  return Number(value).toFixed(3)
}

function getOrderItemSummary(
  order: SalesOrder
) {
  if (!order.items?.length) {
    return '-'
  }

  if (order.items.length === 1) {
    const item = order.items[0]

    return `${getProductName(item.product_id)} × ${item.quantity}`
  }

  return `${order.items.length} 个产品明细`
}

onMounted(async () => {
  await loadData()
  const target = salesOrders.value.find(order => order.id === Number(route.query.order))
  if (target) await loadOrderDetail(target)
})
</script>

<template>
  <div class="sales-order-page">
    <!-- 页面标题 -->
    <div class="business-page-header">
      <div>
        <h1>销售订单</h1>

        <p>
          管理客户需求、库存分配以及生产缺口
        </p>
      </div>

      <div class="business-page-actions">
        <el-button
          :icon="Refresh"
          :loading="loading"
          @click="loadData"
        >
          刷新
        </el-button>

        <el-button
          type="primary"
          :icon="Plus"
          @click="openCreateDialog"
        >
          新增销售订单
        </el-button>
      </div>
    </div>

    <!-- 主列表 -->
    <el-card
      shadow="never"
      class="business-card"
    >
      <el-table
        v-loading="loading"
        :data="salesOrders"
        stripe
        style="width: 100%"
      >
        <el-table-column
          prop="id"
          label="ID"
          width="70"
        />

        <el-table-column
          prop="order_no"
          label="订单号"
          min-width="170"
        >
          <template #default="{ row }">
            <span class="code-text">
              {{ row.order_no }}
            </span>
          </template>
        </el-table-column>

        <el-table-column
          label="客户"
          min-width="210"
        >
          <template #default="{ row }">
            {{
              getCustomerName(
                row.customer_id
              )
            }}
          </template>
        </el-table-column>

        <el-table-column
          label="订单明细"
          min-width="220"
        >
          <template #default="{ row }">
            {{
              getOrderItemSummary(row)
            }}
          </template>
        </el-table-column>

        <el-table-column
          label="总金额"
          min-width="140"
        >
          <template #default="{ row }">
            <span class="money-text">
              ¥
              {{
                formatMoney(
                  row.total_amount
                )
              }}
            </span>
          </template>
        </el-table-column>

        <el-table-column
          label="状态"
          width="110"
        >
          <template #default="{ row }">
            <el-tag
              :type="
                getStatusType(
                  row.status
                )
              "
              effect="light"
              round
            >
              {{
                getStatusText(
                  row.status
                )
              }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column
          label="创建时间"
          min-width="190"
        >
          <template #default="{ row }">
            {{
              formatDate(
                row.created_at
              )
            }}
          </template>
        </el-table-column>

        <el-table-column
          label="操作"
          width="300"
          fixed="right"
        >
          <template #default="{ row }">
            <div class="order-actions">
              <el-button
                link
                type="primary"
                :icon="View"
                @click="
                  loadOrderDetail(row)
                "
              >
                查看详情
              </el-button>

              <el-button
                v-if="
                  row.status === 'draft'
                "
                link
                type="success"
                @click="
                  openConfirmDialog(row)
                "
              >
                确认订单
              </el-button>

              <el-button
                v-if="
                  row.status ===
                  'confirmed'
                "
                link
                type="warning"
                :disabled="saving"
                @click="
                  generateManufacturingOrder(
                    row
                  )
                "
              >
                生成生产订单
              </el-button>
            </div>
          </template>
        </el-table-column>

        <template #empty>
          <el-empty
            description="暂无销售订单"
          />
        </template>
      </el-table>
    </el-card>

    <!-- =======================
         新增销售订单 Dialog
         ======================= -->

    <el-dialog
      v-model="createDialogVisible"
      title="新增销售订单"
      width="820px"
      destroy-on-close
    >
      <el-form label-position="top">
        <div class="order-basic-grid">
          <el-form-item
            label="销售订单号"
            required
          >
            <el-input
              v-model="
                orderForm.order_no
              "
              placeholder="例如 SO-2026-001"
              clearable
            />
          </el-form-item>

          <el-form-item
            label="客户"
            required
          >
            <el-select
              v-model="
                orderForm.customer_id
              "
              placeholder="请选择客户"
              filterable
              style="width: 100%"
            >
              <el-option
                v-for="
                  customer
                  in activeCustomers
                "
                :key="customer.id"
                :label="
                  `${customer.code} / ${customer.name}`
                "
                :value="customer.id"
              />
            </el-select>
          </el-form-item>
        </div>

        <div class="order-lines-header">
          <div>
            <strong>
              产品明细
            </strong>

            <span>
              至少添加一条明细
            </span>
          </div>

          <el-button
            type="primary"
            plain
            :icon="Plus"
            @click="addOrderItem"
          >
            添加产品
          </el-button>
        </div>

        <div
          v-for="
            (item, index)
            in orderForm.items
          "
          :key="index"
          class="order-line"
        >
          <div class="order-line-index">
            {{ index + 1 }}
          </div>

          <div class="order-line-product">
            <label>产品</label>

            <el-select
              v-model="
                item.product_id
              "
              placeholder="请选择产品"
              filterable
              style="width: 100%"
            >
              <el-option
                v-for="
                  product
                  in activeProducts
                "
                :key="product.id"
                :label="
                  `${product.code} / ${product.name}`
                "
                :value="product.id"
              />
            </el-select>
          </div>

          <div class="order-line-number">
            <label>数量</label>

            <el-input-number
              v-model="
                item.quantity
              "
              :min="1"
              :precision="0"
              controls-position="right"
              style="width: 100%"
            />
          </div>

          <div class="order-line-number">
            <label>单价</label>

            <el-input-number
              v-model="
                item.unit_price
              "
              :min="0.01"
              :precision="2"
              :step="100"
              controls-position="right"
              style="width: 100%"
            />
          </div>

          <div class="order-line-delete">
            <el-button
              circle
              plain
              type="danger"
              :icon="Delete"
              @click="
                removeOrderItem(index)
              "
            />
          </div>
        </div>
      </el-form>

      <template #footer>
        <div class="dialog-footer">
          <el-button
            :disabled="saving"
            @click="
              createDialogVisible =
                false
            "
          >
            取消
          </el-button>

          <el-button
            type="primary"
            :loading="saving"
            @click="
              createSalesOrder
            "
          >
            创建销售订单
          </el-button>
        </div>
      </template>
    </el-dialog>

    <!-- =======================
         确认订单 Dialog
         ======================= -->

    <el-dialog
      v-model="confirmDialogVisible"
      title="确认销售订单"
      width="520px"
      destroy-on-close
    >
      <template
        v-if="confirmingOrder"
      >
        <el-alert
          title="确认后系统会执行库存分配，订单不能再次确认。"
          type="warning"
          show-icon
          :closable="false"
          class="confirm-alert"
        />

        <el-descriptions
          :column="1"
          border
          class="confirm-description"
        >
          <el-descriptions-item
            label="订单号"
          >
            {{
              confirmingOrder.order_no
            }}
          </el-descriptions-item>

          <el-descriptions-item
            label="客户"
          >
            {{
              getCustomerName(
                confirmingOrder.customer_id
              )
            }}
          </el-descriptions-item>

          <el-descriptions-item
            label="订单金额"
          >
            ¥
            {{
              formatMoney(
                confirmingOrder.total_amount
              )
            }}
          </el-descriptions-item>
        </el-descriptions>

        <el-form
          label-position="top"
          class="warehouse-form"
        >
          <el-form-item
            label="库存分配仓库"
            required
          >
            <el-select
              v-model="
                confirmWarehouseId
              "
              placeholder="请选择仓库"
              style="width: 100%"
            >
              <el-option
                v-for="
                  warehouse
                  in activeWarehouses
                "
                :key="warehouse.id"
                :label="
                  `${warehouse.code} / ${warehouse.name}`
                "
                :value="warehouse.id"
              />
            </el-select>
          </el-form-item>
        </el-form>
      </template>

      <template #footer>
        <div class="dialog-footer">
          <el-button
            :disabled="saving"
            @click="
              confirmDialogVisible =
                false
            "
          >
            取消
          </el-button>

          <el-button
            type="primary"
            :loading="saving"
            @click="
              confirmSalesOrder
            "
          >
            确认并分配库存
          </el-button>
        </div>
      </template>
    </el-dialog>

    <!-- =======================
         库存分配结果 Dialog
         ======================= -->

    <el-dialog
      v-model="
        confirmResultDialogVisible
      "
      title="库存分配结果"
      width="720px"
    >
      <template v-if="confirmResult">
        <el-result
          icon="success"
          title="销售订单确认成功"
          :sub-title="
            `订单 ${confirmResult.order_no} 已完成库存分配`
          "
        />

        <el-descriptions
          :column="2"
          border
          class="result-description"
        >
          <el-descriptions-item
            label="订单号"
          >
            {{ confirmResult.order_no }}
          </el-descriptions-item>

          <el-descriptions-item
            label="仓库"
          >
            {{
              getWarehouseName(
                confirmResult.warehouse_id
              )
            }}
          </el-descriptions-item>
        </el-descriptions>

        <el-table
          :data="confirmResult.lines"
          stripe
          class="result-table"
        >
          <el-table-column
            label="产品"
            min-width="190"
          >
            <template #default="{ row }">
              {{
                getProductName(
                  row.product_id
                )
              }}
            </template>
          </el-table-column>

          <el-table-column
            label="需求"
            width="100"
          >
            <template #default="{ row }">
              {{
                formatQuantity(
                  row.requested_quantity
                )
              }}
            </template>
          </el-table-column>

          <el-table-column
            label="已预留"
            width="100"
          >
            <template #default="{ row }">
              {{
                formatQuantity(
                  row.reserved_quantity
                )
              }}
            </template>
          </el-table-column>

          <el-table-column
            label="生产缺口"
            width="110"
          >
            <template #default="{ row }">
              <el-tag
                :type="
                  Number(
                    row.shortage_quantity
                  ) > 0
                    ? 'danger'
                    : 'success'
                "
                effect="light"
              >
                {{
                  formatQuantity(
                    row.shortage_quantity
                  )
                }}
              </el-tag>
            </template>
          </el-table-column>
        </el-table>
      </template>

      <template #footer>
        <el-button
          type="primary"
          @click="
            confirmResultDialogVisible =
              false
          "
        >
          知道了
        </el-button>
      </template>
    </el-dialog>

    <!-- =======================
         销售订单详情 Drawer
         ======================= -->

    <el-drawer
      v-model="detailDrawerVisible"
      title="销售订单详情"
      size="720px"
      destroy-on-close
      @closed="closeDetailDrawer"
    >
      <div
        v-loading="detailLoading"
        class="order-detail"
      >
        <template v-if="detailOrder">
          <div class="detail-title">
            <div>
              <span class="detail-label">
                销售订单
              </span>

              <h2>
                {{ detailOrder.order_no }}
              </h2>
            </div>

            <el-tag
              :type="
                getStatusType(
                  detailOrder.status
                )
              "
              effect="light"
              round
              size="large"
            >
              {{
                getStatusText(
                  detailOrder.status
                )
              }}
            </el-tag>
          </div>

          <el-descriptions
            :column="2"
            border
            class="detail-description"
          >
            <el-descriptions-item
              label="客户"
            >
              {{
                getCustomerName(
                  detailOrder.customer_id
                )
              }}
            </el-descriptions-item>

            <el-descriptions-item
              label="订单金额"
            >
              ¥
              {{
                formatMoney(
                  detailOrder.total_amount
                )
              }}
            </el-descriptions-item>

            <el-descriptions-item
              label="创建时间"
            >
              {{
                formatDate(
                  detailOrder.created_at
                )
              }}
            </el-descriptions-item>

            <el-descriptions-item
              label="订单状态"
            >
              {{
                getStatusText(
                  detailOrder.status
                )
              }}
            </el-descriptions-item>
          </el-descriptions>

          <div class="detail-section">
            <div class="detail-section-title">
              履约与生产状态
            </div>

            <el-table
              v-if="orderDetail"
              :data="orderDetail.lines"
              border
            >
              <el-table-column
                label="产品"
                min-width="180"
              >
                <template #default="{ row }">
                  {{
                    getProductName(
                      row.product_id
                    )
                  }}
                </template>
              </el-table-column>

              <el-table-column
                label="需求"
                width="90"
              >
                <template #default="{ row }">
                  {{
                    formatQuantity(
                      row.requested_quantity
                    )
                  }}
                </template>
              </el-table-column>

              <el-table-column
                label="预留"
                width="90"
              >
                <template #default="{ row }">
                  {{
                    formatQuantity(
                      row.reserved_quantity
                    )
                  }}
                </template>
              </el-table-column>

              <el-table-column
                label="缺口"
                width="90"
              >
                <template #default="{ row }">
                  <el-tag
                    :type="
                      Number(
                        row.shortage_quantity
                      ) > 0
                        ? 'danger'
                        : 'success'
                    "
                    effect="light"
                  >
                    {{
                      formatQuantity(
                        row.shortage_quantity
                      )
                    }}
                  </el-tag>
                </template>
              </el-table-column>

              <el-table-column
                label="生产订单"
                min-width="150"
              >
                <template #default="{ row }">
                  <span
                    v-if="
                      row.manufacturing_order_no
                    "
                    class="code-text"
                  >
                    {{
                      row.manufacturing_order_no
                    }}
                  </span>

                  <span v-else>
                    -
                  </span>
                </template>
              </el-table-column>

              <el-table-column
                label="生产状态"
                width="110"
              >
                <template #default="{ row }">
                  <el-tag
                    v-if="
                      row.manufacturing_order_status
                    "
                    :type="
                      getManufacturingStatusType(
                        row.manufacturing_order_status
                      )
                    "
                    effect="light"
                    round
                  >
                    {{
                      getManufacturingStatusText(
                        row.manufacturing_order_status
                      )
                    }}
                  </el-tag>

                  <span v-else>
                    -
                  </span>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </template>
      </div>
    </el-drawer>
  </div>
</template>

<style scoped>
.sales-order-page {
  width: 100%;
}

.business-page-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  gap: 20px;
  margin-bottom: 22px;
}

.business-page-header h1 {
  margin: 0;

  color: #172033;
  font-size: 28px;
  font-weight: 700;
}

.business-page-header p {
  margin: 7px 0 0;

  color: #8a94a5;
  font-size: 14px;
}

.business-page-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.business-card {
  border-radius: 12px;
  border: 1px solid #e7ebf0;
}

.business-card :deep(
  .el-card__body
) {
  padding: 0;
}

.business-card :deep(
  .el-table
) {
  --el-table-border-color:
    #edf0f4;

  --el-table-header-bg-color:
    #f8fafc;

  --el-table-row-hover-bg-color:
    #f6f9fe;
}

.business-card :deep(
  th.el-table__cell
) {
  height: 50px;

  color: #687386;
  font-weight: 600;
}

.business-card :deep(
  td.el-table__cell
) {
  height: 60px;

  color: #354052;
}

.code-text {
  color: #2c7be5;
  font-weight: 600;
}

.money-text {
  color: #172033;
  font-weight: 600;
}

.order-actions {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

.order-basic-grid {
  display: grid;

  grid-template-columns:
    repeat(
      2,
      minmax(0, 1fr)
    );

  gap: 18px;
}

.order-lines-header {
  display: flex;
  align-items: center;
  justify-content: space-between;

  margin: 8px 0 14px;
}

.order-lines-header > div {
  display: flex;
  flex-direction: column;
}

.order-lines-header strong {
  color: #303846;
  font-size: 15px;
}

.order-lines-header span {
  margin-top: 3px;

  color: #9099a8;
  font-size: 12px;
}

.order-line {
  display: grid;

  grid-template-columns:
    36px
    minmax(220px, 1fr)
    130px
    160px
    42px;

  gap: 12px;
  align-items: end;

  padding: 14px;

  margin-bottom: 10px;

  background: #f8fafc;

  border: 1px solid #e8edf3;
  border-radius: 10px;
}

.order-line-index {
  height: 32px;

  display: flex;
  align-items: center;
  justify-content: center;

  color: #6f7b8e;
  font-size: 13px;
  font-weight: 600;
}

.order-line-product,
.order-line-number {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.order-line-product label,
.order-line-number label {
  color: #697487;
  font-size: 12px;
}

.order-line-delete {
  height: 32px;

  display: flex;
  align-items: center;
  justify-content: center;
}

.confirm-alert {
  margin-bottom: 18px;
}

.confirm-description {
  margin-bottom: 20px;
}

.warehouse-form {
  margin-top: 4px;
}

.result-description {
  margin-bottom: 20px;
}

.result-table {
  margin-top: 18px;
}

.detail-title {
  display: flex;
  align-items: center;
  justify-content: space-between;

  padding-bottom: 18px;

  border-bottom: 1px solid #edf0f4;
}

.detail-label {
  color: #929baa;
  font-size: 12px;
}

.detail-title h2 {
  margin: 5px 0 0;

  color: #172033;
  font-size: 23px;
}

.detail-description {
  margin-top: 20px;
}

.detail-section {
  margin-top: 28px;
}

.detail-section-title {
  margin-bottom: 12px;

  color: #303846;
  font-size: 16px;
  font-weight: 700;
}

@media (max-width: 900px) {
  .business-page-header {
    flex-direction: column;
  }

  .order-basic-grid {
    grid-template-columns: 1fr;
  }

  .order-line {
    grid-template-columns: 1fr;
  }

  .order-line-index,
  .order-line-delete {
    justify-content: flex-start;
  }
}
</style>
