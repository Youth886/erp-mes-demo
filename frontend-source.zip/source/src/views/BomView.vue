<script setup lang="ts">
import {
  computed,
  onMounted,
  ref,
} from 'vue'

import {
  Delete,
  Plus,
  Refresh,
} from '@element-plus/icons-vue'

import {
  ElMessage,
} from 'element-plus'

import api from '../services/api'

interface Product {
  id: number
  code: string
  name: string
  unit: string
  active: boolean
}

interface BomItem {
  id: number
  component_product_id: number
  quantity: number | string
}

interface Bom {
  id: number
  product_id: number
  name: string
  active: boolean
  items: BomItem[]
}

interface BomFormItem {
  component_product_id: number | null
  quantity: number
}

const boms = ref<Bom[]>([])
const products = ref<Product[]>([])

const loading = ref(false)
const saving = ref(false)

const createDialogVisible =
  ref(false)

const bomForm = ref({
  product_id: null as number | null,
  name: '',
  items: [
    {
      component_product_id: null,
      quantity: 1,
    },
  ] as BomFormItem[],
})

/* =========================
   可创建 BOM 的成品
   ========================= */

const availableParentProducts = computed(
  () => {
    const usedProductIds =
      new Set(
        boms.value.map(
          bom => bom.product_id
        )
      )

    return products.value.filter(
      product =>
        product.active &&
        !usedProductIds.has(
          product.id
        )
    )
  }
)

/* =========================
   数据加载
   ========================= */

async function loadData() {
  loading.value = true

  try {
    const [
      bomResponse,
      productResponse,
    ] = await Promise.all([
      api.get<Bom[]>('/boms'),

      api.get<Product[]>(
        '/products'
      ),
    ])

    boms.value = bomResponse.data

    products.value =
      productResponse.data
  } catch (error) {
    console.error(error)

    ElMessage.error(
      'BOM 数据加载失败'
    )
  } finally {
    loading.value = false
  }
}

/* =========================
   新增 BOM
   ========================= */

function openCreateDialog() {
  bomForm.value = {
    product_id: null,
    name: '',
    items: [
      {
        component_product_id:
          null,

        quantity: 1,
      },
    ],
  }

  createDialogVisible.value =
    true
}

function addBomItem() {
  bomForm.value.items.push({
    component_product_id: null,
    quantity: 1,
  })
}

function removeBomItem(
  index: number
) {
  if (
    bomForm.value.items.length <=
    1
  ) {
    ElMessage.warning(
      'BOM 至少需要一条物料明细'
    )

    return
  }

  bomForm.value.items.splice(
    index,
    1
  )
}

function getComponentOptions() {
  return products.value.filter(
    product =>
      product.active &&
      product.id !==
        bomForm.value.product_id
  )
}

async function createBom() {
  if (
    bomForm.value.product_id ===
    null
  ) {
    ElMessage.warning(
      '请选择成品'
    )

    return
  }

  if (
    !bomForm.value.name.trim()
  ) {
    ElMessage.warning(
      '请输入 BOM 名称'
    )

    return
  }

  if (
    bomForm.value.items.length ===
    0
  ) {
    ElMessage.warning(
      'BOM 至少需要一条物料明细'
    )

    return
  }

  const componentIds =
    bomForm.value.items.map(
      item =>
        item.component_product_id
    )

  if (
    componentIds.some(
      id => id === null
    )
  ) {
    ElMessage.warning(
      '请选择所有 BOM 物料'
    )

    return
  }

  const normalizedIds =
    componentIds.map(
      id => Number(id)
    )

  if (
    new Set(normalizedIds).size !==
    normalizedIds.length
  ) {
    ElMessage.warning(
      '同一个物料不能重复添加'
    )

    return
  }

  for (
    const item of bomForm.value.items
  ) {
    if (item.quantity <= 0) {
      ElMessage.warning(
        '物料用量必须大于 0'
      )

      return
    }
  }

  saving.value = true

  try {
    await api.post(
      '/boms',
      {
        product_id:
          bomForm.value.product_id,

        name:
          bomForm.value.name.trim(),

        items:
          bomForm.value.items.map(
            item => ({
              component_product_id:
                Number(
                  item.component_product_id
                ),

              quantity:
                item.quantity,
            })
          ),
      }
    )

    ElMessage.success(
      'BOM 创建成功'
    )

    createDialogVisible.value =
      false

    await loadData()
  } catch (error: any) {
    console.error(error)

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `创建失败：${detail}`
        : 'BOM 创建失败'
    )
  } finally {
    saving.value = false
  }
}

/* =========================
   显示辅助
   ========================= */

function getProduct(
  productId: number
) {
  return products.value.find(
    product =>
      product.id === productId
  )
}

function getProductName(
  productId: number
) {
  const product =
    getProduct(productId)

  if (!product) {
    return `产品 #${productId}`
  }

  return (
    `${product.code} / ` +
    `${product.name}`
  )
}

function getProductUnit(
  productId: number
) {
  return (
    getProduct(productId)
      ?.unit ?? ''
  )
}

function formatQuantity(
  value: number | string
) {
  return Number(value).toFixed(3)
}

onMounted(() => {
  loadData()
})
</script>

<template>
  <div class="bom-page">
    <!-- 页面标题 -->
    <div class="business-page-header">
      <div>
        <h1>BOM 物料清单</h1>

        <p>
          维护产品组成关系，
          定义生产一个成品所需的物料与用量
        </p>
      </div>

      <div class="business-page-actions">
        <el-button
          :icon="Refresh"
          :loading="loading"
          @click="loadData"
        >
          刷新
        </el-button>

        <el-button
          type="primary"
          :icon="Plus"
          @click="openCreateDialog"
        >
          新增 BOM
        </el-button>
      </div>
    </div>

    <!-- BOM 列表 -->
    <div
      v-loading="loading"
      class="bom-grid"
    >
      <el-card
        v-for="bom in boms"
        :key="bom.id"
        shadow="never"
        class="bom-card"
      >
        <div class="bom-card-header">
          <div>
            <span class="bom-label">
              BOM
            </span>

            <h2>
              {{ bom.name }}
            </h2>
          </div>

          <el-tag
            :type="
              bom.active
                ? 'success'
                : 'info'
            "
            effect="light"
            round
          >
            {{
              bom.active
                ? '启用'
                : '停用'
            }}
          </el-tag>
        </div>

        <div class="bom-product">
          <span>成品</span>

          <strong>
            {{
              getProductName(
                bom.product_id
              )
            }}
          </strong>

          <small>
            单位：
            {{
              getProductUnit(
                bom.product_id
              )
            }}
          </small>
        </div>

        <div class="bom-section-header">
          <div>
            <strong>
              物料明细
            </strong>

            <span>
              共
              {{ bom.items.length }}
              项物料
            </span>
          </div>
        </div>

        <el-table
          :data="bom.items"
          size="small"
          border
          style="width: 100%"
        >
          <el-table-column
            label="物料"
            min-width="220"
          >
            <template #default="{ row }">
              <div class="component-cell">
                <strong>
                  {{
                    getProductName(
                      row.component_product_id
                    )
                  }}
                </strong>

                <span>
                  单位：
                  {{
                    getProductUnit(
                      row.component_product_id
                    )
                  }}
                </span>
              </div>
            </template>
          </el-table-column>

          <el-table-column
            label="单位"
            width="90"
          >
            <template #default="{ row }">
              {{
                getProductUnit(
                  row.component_product_id
                )
              }}
            </template>
          </el-table-column>

          <el-table-column
            label="单位用量"
            width="130"
            align="right"
          >
            <template #default="{ row }">
              <span class="quantity-text">
                {{
                  formatQuantity(
                    row.quantity
                  )
                }}
              </span>
            </template>
          </el-table-column>
        </el-table>
      </el-card>

      <el-empty
        v-if="
          !loading &&
          boms.length === 0
        "
        description="暂无 BOM"
        class="bom-empty"
      />
    </div>

    <!-- =======================
         新增 BOM Dialog
         ======================= -->

    <el-dialog
      v-model="createDialogVisible"
      title="新增 BOM"
      width="760px"
      destroy-on-close
    >
      <el-form
        label-position="top"
      >
        <div class="bom-basic-grid">
          <el-form-item
            label="成品"
            required
          >
            <el-select
              v-model="
                bomForm.product_id
              "
              placeholder="请选择成品"
              filterable
              style="width: 100%"
            >
              <el-option
                v-for="
                  product
                  in availableParentProducts
                "
                :key="product.id"
                :label="
                  `${product.code} / ${product.name}`
                "
                :value="product.id"
              />
            </el-select>
          </el-form-item>

          <el-form-item
            label="BOM 名称"
            required
          >
            <el-input
              v-model="
                bomForm.name
              "
              placeholder="例如 高效电机X标准BOM"
              clearable
            />
          </el-form-item>
        </div>

        <div class="bom-item-header">
          <div>
            <strong>
              物料明细
            </strong>

            <span>
              填写生产 1 个成品所需的物料用量
            </span>
          </div>

          <el-button
            type="primary"
            plain
            :icon="Plus"
            @click="addBomItem"
          >
            添加物料
          </el-button>
        </div>

        <div
          v-for="
            (item, index)
            in bomForm.items
          "
          :key="index"
          class="bom-item-row"
        >
          <div class="bom-item-index">
            {{ index + 1 }}
          </div>

          <div>
            <label>
              物料
            </label>

            <el-select
              v-model="
                item.component_product_id
              "
              placeholder="请选择物料"
              filterable
              style="width: 100%"
            >
              <el-option
                v-for="
                  product
                  in getComponentOptions()
                "
                :key="product.id"
                :label="
                  `${product.code} / ${product.name}`
                "
                :value="product.id"
              />
            </el-select>
          </div>

          <div>
            <label>
              单位用量
            </label>

            <el-input-number
              v-model="
                item.quantity
              "
              :min="0.001"
              :precision="3"
              :step="1"
              controls-position="right"
              style="width: 100%"
            />
          </div>

          <div class="bom-item-delete">
            <el-button
              circle
              plain
              type="danger"
              :icon="Delete"
              @click="
                removeBomItem(index)
              "
            />
          </div>
        </div>
      </el-form>

      <template #footer>
        <div class="dialog-footer">
          <el-button
            :disabled="saving"
            @click="
              createDialogVisible =
                false
            "
          >
            取消
          </el-button>

          <el-button
            type="primary"
            :loading="saving"
            @click="createBom"
          >
            创建 BOM
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.bom-page {
  width: 100%;
}

.business-page-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  gap: 20px;
  margin-bottom: 22px;
}

.business-page-header h1 {
  margin: 0;

  color: #172033;

  font-size: 28px;
  font-weight: 700;
}

.business-page-header p {
  margin: 7px 0 0;

  color: #8a94a5;
  font-size: 14px;
}

.business-page-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

/* BOM 卡片 */

.bom-grid {
  display: grid;

  grid-template-columns:
    repeat(
      2,
      minmax(0, 1fr)
    );

  gap: 18px;
}

.bom-card {
  border-radius: 12px;

  border:
    1px solid #e7ebf0;
}

.bom-card-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  gap: 20px;
}

.bom-label {
  color: #949dac;
  font-size: 11px;
}

.bom-card-header h2 {
  margin: 5px 0 0;

  color: #172033;
  font-size: 19px;
}

.bom-product {
  display: flex;
  flex-direction: column;

  gap: 4px;

  margin-top: 18px;

  padding: 14px 16px;

  border-radius: 9px;

  background: #f7f9fc;
}

.bom-product span {
  color: #929baa;
  font-size: 11px;
}

.bom-product strong {
  color: #2c7be5;
  font-size: 14px;
}

.bom-product small {
  color: #9aa3b1;
}

.bom-section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;

  margin: 20px 0 12px;
}

.bom-section-header > div {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.bom-section-header strong {
  color: #354052;
}

.bom-section-header span {
  color: #929baa;
  font-size: 11px;
}

.component-cell {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.component-cell strong {
  color: #354052;
}

.component-cell span {
  color: #9aa3b1;
  font-size: 11px;
}

.quantity-text {
  color: #172033;
  font-weight: 700;
}

.bom-empty {
  grid-column: 1 / -1;
}

/* Dialog */

.bom-basic-grid {
  display: grid;

  grid-template-columns:
    repeat(
      2,
      minmax(0, 1fr)
    );

  gap: 18px;
}

.bom-item-header {
  display: flex;
  align-items: center;
  justify-content: space-between;

  margin: 6px 0 14px;
}

.bom-item-header > div {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.bom-item-header strong {
  color: #303846;
}

.bom-item-header span {
  color: #949dac;
  font-size: 11px;
}

.bom-item-row {
  display: grid;

  grid-template-columns:
    34px
    1fr
    170px
    40px;

  gap: 12px;

  align-items: end;

  padding: 13px;

  margin-bottom: 10px;

  border:
    1px solid #e8edf3;

  border-radius: 9px;

  background: #f8fafc;
}

.bom-item-row label {
  display: block;

  margin-bottom: 6px;

  color: #687386;
  font-size: 11px;
}

.bom-item-index {
  height: 32px;

  display: flex;
  align-items: center;
  justify-content: center;

  color: #8d97a7;
}

.bom-item-delete {
  height: 32px;

  display: flex;
  align-items: center;
  justify-content: center;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

@media (max-width: 900px) {
  .bom-grid,
  .bom-basic-grid {
    grid-template-columns: 1fr;
  }

  .business-page-header {
    flex-direction: column;
  }

  .bom-item-row {
    grid-template-columns: 1fr;
  }
}
</style>