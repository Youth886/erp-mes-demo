<script setup lang="ts">
import {
  computed,
  onMounted,
  ref,
} from 'vue'

import {
  Goods,
  Lock,
  Refresh,
  Search,
  Wallet,
} from '@element-plus/icons-vue'

import {
  ElMessage,
} from 'element-plus'

import api from '../services/api'

interface Inventory {
  id: number
  warehouse_id: number
  product_id: number
  on_hand_quantity: number | string
  reserved_quantity: number | string
  available_quantity: number | string
}

interface Warehouse {
  id: number
  code: string
  name: string
  active: boolean
}

interface Product {
  id: number
  code: string
  name: string
  unit: string
  active: boolean
}

type TagType =
  | 'success'
  | 'warning'
  | 'danger'
  | 'info'
  | 'primary'

const inventory = ref<Inventory[]>([])
const warehouses = ref<Warehouse[]>([])
const products = ref<Product[]>([])

const loading = ref(false)

const selectedWarehouseId =
  ref<number | null>(null)

const selectedProductId =
  ref<number | null>(null)

/* =========================
   加载数据
   ========================= */

async function loadData() {
  loading.value = true

  try {
    const [
      inventoryResponse,
      warehouseResponse,
      productResponse,
    ] = await Promise.all([
      api.get<Inventory[]>(
        '/inventory'
      ),

      api.get<Warehouse[]>(
        '/warehouses'
      ),

      api.get<Product[]>(
        '/products'
      ),
    ])

    inventory.value =
      inventoryResponse.data

    warehouses.value =
      warehouseResponse.data

    products.value =
      productResponse.data
  } catch (error) {
    console.error(error)

    ElMessage.error(
      '库存数据加载失败'
    )
  } finally {
    loading.value = false
  }
}

/* =========================
   汇总指标
   ========================= */

const totalOnHand = computed(
  () =>
    inventory.value.reduce(
      (total, item) =>
        total +
        Number(
          item.on_hand_quantity
        ),
      0
    )
)

const totalReserved = computed(
  () =>
    inventory.value.reduce(
      (total, item) =>
        total +
        Number(
          item.reserved_quantity
        ),
      0
    )
)

const totalAvailable = computed(
  () =>
    inventory.value.reduce(
      (total, item) =>
        total +
        Number(
          item.available_quantity
        ),
      0
    )
)

const inventoryRecordCount = computed(
  () => inventory.value.length
)

/* =========================
   筛选
   ========================= */

const filteredInventory = computed(
  () =>
    inventory.value.filter(
      item => {
        const warehouseMatched =
          selectedWarehouseId.value ===
            null ||
          item.warehouse_id ===
            selectedWarehouseId.value

        const productMatched =
          selectedProductId.value ===
            null ||
          item.product_id ===
            selectedProductId.value

        return (
          warehouseMatched &&
          productMatched
        )
      }
    )
)

function clearFilters() {
  selectedWarehouseId.value = null
  selectedProductId.value = null
}

/* =========================
   显示辅助
   ========================= */

function getWarehouseName(
  warehouseId: number
) {
  const warehouse =
    warehouses.value.find(
      item =>
        item.id === warehouseId
    )

  if (!warehouse) {
    return `仓库 #${warehouseId}`
  }

  return (
    `${warehouse.code} / ` +
    `${warehouse.name}`
  )
}

function getProductName(
  productId: number
) {
  const product =
    products.value.find(
      item =>
        item.id === productId
    )

  if (!product) {
    return `产品 #${productId}`
  }

  return (
    `${product.code} / ` +
    `${product.name}`
  )
}

function getProductUnit(
  productId: number
) {
  const product =
    products.value.find(
      item =>
        item.id === productId
    )

  return product?.unit ?? ''
}

function formatQuantity(
  value: number | string
) {
  return Number(value).toFixed(3)
}

function getReservationRate(
  row: Inventory
) {
  const onHand =
    Number(row.on_hand_quantity)

  const reserved =
    Number(row.reserved_quantity)

  if (onHand <= 0) {
    return 0
  }

  return Math.min(
    100,
    Math.round(
      (reserved / onHand) * 100
    )
  )
}

function getInventoryStatus(
  row: Inventory
) {
  const onHand =
    Number(row.on_hand_quantity)

  const reserved =
    Number(row.reserved_quantity)

  const available =
    Number(row.available_quantity)

  if (available < 0) {
    return '库存异常'
  }

  if (onHand <= 0) {
    return '无库存'
  }

  if (
    available === 0 &&
    reserved > 0
  ) {
    return '全部预留'
  }

  return '库存可用'
}

function getInventoryStatusType(
  row: Inventory
): TagType {
  const status =
    getInventoryStatus(row)

  const statusMap:
    Record<string, TagType> = {
      库存可用: 'success',
      全部预留: 'warning',
      无库存: 'info',
      库存异常: 'danger',
    }

  return (
    statusMap[status] ??
    'info'
  )
}

onMounted(() => {
  loadData()
})
</script>

<template>
  <div class="inventory-page">
    <!-- 页面标题 -->
    <div class="business-page-header">
      <div>
        <h1>库存管理</h1>

        <p>
          查看仓库库存、销售预留与当前可用数量
        </p>
      </div>

      <div class="business-page-actions">
        <el-button
          :icon="Refresh"
          :loading="loading"
          @click="loadData"
        >
          刷新
        </el-button>
      </div>
    </div>

    <!-- 库存概览 -->
    <div class="inventory-summary-grid">
      <el-card
        shadow="never"
        class="inventory-summary-card"
      >
        <div class="summary-card-content">
          <div
            class="summary-icon
                   summary-icon-blue"
          >
            <el-icon>
              <Goods />
            </el-icon>
          </div>

          <div>
            <div class="summary-label">
              现有库存
            </div>

            <div class="summary-value">
              {{
                totalOnHand.toFixed(3)
              }}
            </div>

            <div class="summary-note">
              当前实物库存总量
            </div>
          </div>
        </div>
      </el-card>

      <el-card
        shadow="never"
        class="inventory-summary-card"
      >
        <div class="summary-card-content">
          <div
            class="summary-icon
                   summary-icon-orange"
          >
            <el-icon>
              <Lock />
            </el-icon>
          </div>

          <div>
            <div class="summary-label">
              预留库存
            </div>

            <div class="summary-value">
              {{
                totalReserved.toFixed(3)
              }}
            </div>

            <div class="summary-note">
              已分配给销售订单
            </div>
          </div>
        </div>
      </el-card>

      <el-card
        shadow="never"
        class="inventory-summary-card"
      >
        <div class="summary-card-content">
          <div
            class="summary-icon
                   summary-icon-green"
          >
            <el-icon>
              <Wallet />
            </el-icon>
          </div>

          <div>
            <div class="summary-label">
              可用库存
            </div>

            <div class="summary-value">
              {{
                totalAvailable.toFixed(3)
              }}
            </div>

            <div class="summary-note">
              可供新订单使用
            </div>
          </div>
        </div>
      </el-card>

      <el-card
        shadow="never"
        class="inventory-summary-card"
      >
        <div class="summary-card-content">
          <div
            class="summary-icon
                   summary-icon-purple"
          >
            <el-icon>
              <Search />
            </el-icon>
          </div>

          <div>
            <div class="summary-label">
              库存记录
            </div>

            <div class="summary-value">
              {{
                inventoryRecordCount
              }}
            </div>

            <div class="summary-note">
              仓库 / 产品库存组合
            </div>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 筛选与表格 -->
    <el-card
      shadow="never"
      class="inventory-table-card"
    >
      <div class="inventory-toolbar">
        <div class="inventory-toolbar-left">
          <el-select
            v-model="
              selectedWarehouseId
            "
            placeholder="全部仓库"
            clearable
            filterable
            style="width: 220px"
          >
            <el-option
              v-for="
                warehouse
                in warehouses
              "
              :key="warehouse.id"
              :label="
                `${warehouse.code} / ${warehouse.name}`
              "
              :value="warehouse.id"
            />
          </el-select>

          <el-select
            v-model="
              selectedProductId
            "
            placeholder="全部产品"
            clearable
            filterable
            style="width: 240px"
          >
            <el-option
              v-for="
                product
                in products
              "
              :key="product.id"
              :label="
                `${product.code} / ${product.name}`
              "
              :value="product.id"
            />
          </el-select>

          <el-button
            @click="clearFilters"
          >
            清除筛选
          </el-button>
        </div>

        <div class="inventory-toolbar-count">
          共
          <strong>
            {{
              filteredInventory.length
            }}
          </strong>
          条库存记录
        </div>
      </div>

      <el-table
        v-loading="loading"
        :data="filteredInventory"
        stripe
        style="width: 100%"
      >
        <el-table-column
          label="仓库"
          min-width="190"
        >
          <template #default="{ row }">
            <span class="warehouse-text">
              {{
                getWarehouseName(
                  row.warehouse_id
                )
              }}
            </span>
          </template>
        </el-table-column>

        <el-table-column
          label="产品"
          min-width="220"
        >
          <template #default="{ row }">
            <div class="product-cell">
              <span class="code-text">
                {{
                  getProductName(
                    row.product_id
                  )
                }}
              </span>

              <span class="unit-text">
                单位：
                {{
                  getProductUnit(
                    row.product_id
                  )
                }}
              </span>
            </div>
          </template>
        </el-table-column>

        <el-table-column
          label="现有库存"
          width="130"
          align="right"
        >
          <template #default="{ row }">
            <span class="quantity-text">
              {{
                formatQuantity(
                  row.on_hand_quantity
                )
              }}
            </span>
          </template>
        </el-table-column>

        <el-table-column
          label="预留库存"
          width="130"
          align="right"
        >
          <template #default="{ row }">
            <span class="reserved-text">
              {{
                formatQuantity(
                  row.reserved_quantity
                )
              }}
            </span>
          </template>
        </el-table-column>

        <el-table-column
          label="可用库存"
          width="130"
          align="right"
        >
          <template #default="{ row }">
            <span
              :class="{
                'available-positive':
                  Number(
                    row.available_quantity
                  ) > 0,

                'available-zero':
                  Number(
                    row.available_quantity
                  ) === 0,

                'available-negative':
                  Number(
                    row.available_quantity
                  ) < 0,
              }"
            >
              {{
                formatQuantity(
                  row.available_quantity
                )
              }}
            </span>
          </template>
        </el-table-column>

        <el-table-column
          label="预留比例"
          min-width="170"
        >
          <template #default="{ row }">
            <div class="reservation-cell">
              <el-progress
                :percentage="
                  getReservationRate(row)
                "
                :stroke-width="7"
              />

              <span>
                {{
                  getReservationRate(row)
                }}%
              </span>
            </div>
          </template>
        </el-table-column>

        <el-table-column
          label="库存状态"
          width="130"
          fixed="right"
        >
          <template #default="{ row }">
            <el-tag
              :type="
                getInventoryStatusType(
                  row
                )
              "
              effect="light"
              round
            >
              {{
                getInventoryStatus(row)
              }}
            </el-tag>
          </template>
        </el-table-column>

        <template #empty>
          <el-empty
            description="暂无符合条件的库存记录"
          />
        </template>
      </el-table>
    </el-card>
  </div>
</template>

<style scoped>
.inventory-page {
  width: 100%;
}

.business-page-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  gap: 20px;
  margin-bottom: 22px;
}

.business-page-header h1 {
  margin: 0;

  color: #172033;
  font-size: 28px;
  font-weight: 700;
}

.business-page-header p {
  margin: 7px 0 0;

  color: #8a94a5;
  font-size: 14px;
}

.business-page-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

/* 汇总卡片 */

.inventory-summary-grid {
  display: grid;

  grid-template-columns:
    repeat(
      4,
      minmax(0, 1fr)
    );

  gap: 16px;
  margin-bottom: 22px;
}

.inventory-summary-card {
  border-radius: 12px;
  border: 1px solid #e7ebf0;
}

.inventory-summary-card :deep(
  .el-card__body
) {
  padding: 20px;
}

.summary-card-content {
  display: flex;
  align-items: center;
  gap: 16px;
}

.summary-icon {
  width: 46px;
  height: 46px;

  flex-shrink: 0;

  display: flex;
  align-items: center;
  justify-content: center;

  border-radius: 12px;

  font-size: 22px;
}

.summary-icon-blue {
  color: #2c7be5;
  background: #edf4ff;
}

.summary-icon-orange {
  color: #d79024;
  background: #fff5e5;
}

.summary-icon-green {
  color: #3b9d64;
  background: #ebf8f0;
}

.summary-icon-purple {
  color: #7763c5;
  background: #f1edff;
}

.summary-label {
  color: #7d8796;
  font-size: 13px;
}

.summary-value {
  margin-top: 4px;

  color: #172033;
  font-size: 24px;
  font-weight: 700;
}

.summary-note {
  margin-top: 3px;

  color: #9aa3b1;
  font-size: 11px;
}

/* 库存表 */

.inventory-table-card {
  border-radius: 12px;
  border: 1px solid #e7ebf0;
}

.inventory-table-card :deep(
  .el-card__body
) {
  padding: 0;
}

.inventory-toolbar {
  min-height: 68px;

  display: flex;
  align-items: center;
  justify-content: space-between;

  gap: 20px;

  padding: 14px 18px;

  border-bottom: 1px solid #edf0f4;
}

.inventory-toolbar-left {
  display: flex;
  align-items: center;
  gap: 10px;

  flex-wrap: wrap;
}

.inventory-toolbar-count {
  color: #8a94a5;
  font-size: 13px;

  white-space: nowrap;
}

.inventory-toolbar-count strong {
  color: #2c7be5;
}

.inventory-table-card :deep(
  .el-table
) {
  --el-table-border-color:
    #edf0f4;

  --el-table-header-bg-color:
    #f8fafc;

  --el-table-row-hover-bg-color:
    #f6f9fe;
}

.inventory-table-card :deep(
  th.el-table__cell
) {
  height: 50px;

  color: #687386;
  font-weight: 600;
}

.inventory-table-card :deep(
  td.el-table__cell
) {
  height: 64px;

  color: #354052;
}

.warehouse-text {
  color: #354052;
  font-weight: 600;
}

.product-cell {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.code-text {
  color: #2c7be5;
  font-weight: 600;
}

.unit-text {
  color: #98a1af;
  font-size: 11px;
}

.quantity-text {
  color: #172033;
  font-weight: 600;
}

.reserved-text {
  color: #d79024;
  font-weight: 600;
}

.available-positive {
  color: #3b9d64;
  font-weight: 700;
}

.available-zero {
  color: #d79024;
  font-weight: 700;
}

.available-negative {
  color: #f56c6c;
  font-weight: 700;
}

.reservation-cell {
  display: flex;
  align-items: center;
  gap: 10px;
}

.reservation-cell
:deep(.el-progress) {
  flex: 1;
}

.reservation-cell span {
  min-width: 38px;

  color: #7d8796;
  font-size: 12px;
}

@media (max-width: 1100px) {
  .inventory-summary-grid {
    grid-template-columns:
      repeat(
        2,
        minmax(0, 1fr)
      );
  }
}

@media (max-width: 760px) {
  .business-page-header,
  .inventory-toolbar {
    flex-direction: column;
    align-items: stretch;
  }

  .inventory-summary-grid {
    grid-template-columns: 1fr;
  }
}
</style>