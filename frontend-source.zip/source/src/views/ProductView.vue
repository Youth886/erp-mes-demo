<script setup lang="ts">
import { onMounted, ref } from 'vue'
import {
  Edit,
  Plus,
  Refresh,
  SwitchButton,
} from '@element-plus/icons-vue'
import {
  ElMessage,
  ElMessageBox,
} from 'element-plus'

import api from '../services/api'

interface Product {
  id: number
  code: string
  name: string
  unit: string
  active: boolean
}

const products = ref<Product[]>([])

const loading = ref(false)
const saving = ref(false)

const dialogVisible = ref(false)

const dialogMode = ref<'create' | 'edit'>(
  'create'
)

const editingProductId =
  ref<number | null>(null)

const productForm = ref({
  code: '',
  name: '',
  unit: '',
})

async function loadProducts() {
  loading.value = true

  try {
    const response =
      await api.get<Product[]>('/products')

    products.value = response.data
  } catch (error) {
    console.error(error)

    ElMessage.error(
      '产品数据加载失败'
    )
  } finally {
    loading.value = false
  }
}

function openCreateDialog() {
  dialogMode.value = 'create'
  editingProductId.value = null

  productForm.value = {
    code: '',
    name: '',
    unit: '',
  }

  dialogVisible.value = true
}

function openEditDialog(
  product: Product
) {
  dialogMode.value = 'edit'
  editingProductId.value = product.id

  productForm.value = {
    code: product.code,
    name: product.name,
    unit: product.unit,
  }

  dialogVisible.value = true
}

async function saveProduct() {
  if (
    !productForm.value.code.trim() ||
    !productForm.value.name.trim() ||
    !productForm.value.unit.trim()
  ) {
    ElMessage.warning(
      '产品编码、产品名称和单位不能为空'
    )

    return
  }

  saving.value = true

  try {
    const payload = {
      code: productForm.value.code.trim(),
      name: productForm.value.name.trim(),
      unit: productForm.value.unit.trim(),
    }

    if (
      dialogMode.value === 'create'
    ) {
      await api.post(
        '/products',
        payload
      )

      ElMessage.success(
        '产品新增成功'
      )
    } else {
      if (
        editingProductId.value === null
      ) {
        return
      }

      await api.put(
        `/products/${editingProductId.value}`,
        payload
      )

      ElMessage.success(
        '产品修改成功'
      )
    }

    dialogVisible.value = false

    await loadProducts()
  } catch (error: any) {
    console.error(error)

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `保存失败：${detail}`
        : '产品保存失败'
    )
  } finally {
    saving.value = false
  }
}

async function toggleProductStatus(
  product: Product
) {
  const actionText =
    product.active
      ? '停用'
      : '启用'

  try {
    await ElMessageBox.confirm(
      `确定要${actionText}产品“${product.code} / ${product.name}”吗？`,
      `${actionText}产品`,
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: product.active
          ? 'warning'
          : 'success',
      }
    )
  } catch {
    return
  }

  saving.value = true

  try {
    const endpoint =
      product.active
        ? `/products/${product.id}/deactivate`
        : `/products/${product.id}/activate`

    await api.patch(endpoint)

    ElMessage.success(
      `${actionText}成功`
    )

    await loadProducts()
  } catch (error: any) {
    console.error(error)

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `${actionText}失败：${detail}`
        : `${actionText}产品失败`
    )
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  loadProducts()
})
</script>

<template>
  <div class="product-page">
    <div class="business-page-header">
      <div>
        <h1>产品管理</h1>

        <p>
          维护 ERP 产品主数据、
          产品状态与基础信息
        </p>
      </div>

      <div class="business-page-actions">
        <el-button
          :icon="Refresh"
          :loading="loading"
          @click="loadProducts"
        >
          刷新
        </el-button>

        <el-button
          type="primary"
          :icon="Plus"
          @click="openCreateDialog"
        >
          新增产品
        </el-button>
      </div>
    </div>

    <el-card
      shadow="never"
      class="business-card"
    >
      <el-table
        v-loading="loading"
        :data="products"
        stripe
        style="width: 100%"
      >
        <el-table-column
          prop="id"
          label="ID"
          width="80"
        />

        <el-table-column
          prop="code"
          label="产品编码"
          min-width="170"
        >
          <template #default="{ row }">
            <span class="code-text">
              {{ row.code }}
            </span>
          </template>
        </el-table-column>

        <el-table-column
          prop="name"
          label="产品名称"
          min-width="200"
        />

        <el-table-column
          prop="unit"
          label="单位"
          width="110"
        />

        <el-table-column
          label="状态"
          width="120"
        >
          <template #default="{ row }">
            <el-tag
              :type="
                row.active
                  ? 'success'
                  : 'info'
              "
              effect="light"
              round
            >
              {{
                row.active
                  ? '启用'
                  : '停用'
              }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column
          label="操作"
          width="210"
          fixed="right"
        >
          <template #default="{ row }">
            <el-button
              link
              type="primary"
              :icon="Edit"
              @click="
                openEditDialog(row)
              "
            >
              编辑
            </el-button>

            <el-button
              link
              :type="
                row.active
                  ? 'danger'
                  : 'success'
              "
              :icon="SwitchButton"
              :disabled="saving"
              @click="
                toggleProductStatus(row)
              "
            >
              {{
                row.active
                  ? '停用'
                  : '启用'
              }}
            </el-button>
          </template>
        </el-table-column>

        <template #empty>
          <el-empty
            description="暂无产品数据"
          />
        </template>
      </el-table>
    </el-card>

    <el-dialog
      v-model="dialogVisible"
      :title="
        dialogMode === 'create'
          ? '新增产品'
          : '编辑产品'
      "
      width="520px"
      destroy-on-close
    >
      <el-form
        label-position="top"
      >
        <el-form-item
          label="产品编码"
          required
        >
          <el-input
            v-model="productForm.code"
            placeholder="例如 MOTOR-B"
            clearable
          />
        </el-form-item>

        <el-form-item
          label="产品名称"
          required
        >
          <el-input
            v-model="productForm.name"
            placeholder="例如 高效电机B"
            clearable
          />
        </el-form-item>

        <el-form-item
          label="单位"
          required
        >
          <el-input
            v-model="productForm.unit"
            placeholder="例如 台"
            clearable
          />
        </el-form-item>
      </el-form>

      <template #footer>
        <div class="dialog-footer">
          <el-button
            :disabled="saving"
            @click="
              dialogVisible = false
            "
          >
            取消
          </el-button>

          <el-button
            type="primary"
            :loading="saving"
            @click="saveProduct"
          >
            {{
              dialogMode === 'create'
                ? '创建产品'
                : '保存修改'
            }}
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.product-page {
  width: 100%;
}

.business-page-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  gap: 20px;
  margin-bottom: 22px;
}

.business-page-header h1 {
  margin: 0;

  color: #172033;

  font-size: 28px;
  font-weight: 700;
}

.business-page-header p {
  margin: 7px 0 0;

  color: #8a94a5;
  font-size: 14px;
}

.business-page-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.business-card {
  border-radius: 12px;
  border: 1px solid #e7ebf0;
}

.business-card :deep(
  .el-card__body
) {
  padding: 0;
}

.business-card :deep(
  .el-table
) {
  --el-table-border-color:
    #edf0f4;

  --el-table-header-bg-color:
    #f8fafc;

  --el-table-row-hover-bg-color:
    #f6f9fe;
}

.business-card :deep(
  th.el-table__cell
) {
  height: 50px;

  color: #687386;
  font-weight: 600;
}

.business-card :deep(
  td.el-table__cell
) {
  height: 58px;

  color: #354052;
}

.code-text {
  color: #2c7be5;
  font-weight: 600;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

@media (max-width: 700px) {
  .business-page-header {
    flex-direction: column;
  }
}
</style>