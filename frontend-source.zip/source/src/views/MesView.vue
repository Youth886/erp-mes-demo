<script setup lang="ts">
import {
  computed,
  onMounted,
  ref,
} from 'vue'

import {
  CircleCheck,
  Clock,
  Refresh,
  Tickets,
} from '@element-plus/icons-vue'

import {
  ElMessage,
} from 'element-plus'

import api from '../services/api'
import { useRoute } from 'vue-router'
const route = useRoute()

interface ManufacturingOrder {
  id: number
  order_no: string
  product_id: number
  planned_quantity: number | string
  source_sales_order_id: number | null
  source_sales_order_item_id: number | null
  status: string
  created_at: string
}

interface ManufacturingOperation {
  id: number
  manufacturing_order_id: number
  sequence: number

  operation_name?: string
  name?: string

  planned_quantity: number | string
  completed_quantity: number | string
  status: string
}

interface Product {
  id: number
  code: string
  name: string
  unit: string
  active: boolean
}

type TagType =
  | 'success'
  | 'warning'
  | 'info'
  | 'primary'
  | 'danger'

const manufacturingOrders =
  ref<ManufacturingOrder[]>([])

const products =
  ref<Product[]>([])

const operations =
  ref<ManufacturingOperation[]>([])

const selectedOrderId =
  ref<number | null>(null)

const loadingOrders = ref(false)
const loadingOperations = ref(false)

const reportDialogVisible =
  ref(false)

const reportingOperation =
  ref<ManufacturingOperation | null>(
    null
  )

const reportSaving = ref(false)

const reportForm = ref({
  operator_name: '',
  good_quantity: 0,
  defect_quantity: 0,
  remark: '',
})

/* =========================
   当前生产订单
   ========================= */

const selectedOrder = computed(
  () =>
    manufacturingOrders.value.find(
      order =>
        order.id ===
        selectedOrderId.value
    ) ?? null
)

/* =========================
   数据加载
   ========================= */

async function loadData() {
  loadingOrders.value = true

  try {
    const [
      orderResponse,
      productResponse,
    ] = await Promise.all([
      api.get<ManufacturingOrder[]>(
        '/manufacturing-orders'
      ),

      api.get<Product[]>(
        '/products'
      ),
    ])

    manufacturingOrders.value =
      orderResponse.data

    products.value =
      productResponse.data

    const requestedOrder = Number(route.query.order)
    if (selectedOrderId.value === null && manufacturingOrders.value.some(order => order.id === requestedOrder)) {
      selectedOrderId.value = requestedOrder
    }

    const currentOrderStillExists =
      manufacturingOrders.value.some(
        order =>
          order.id ===
          selectedOrderId.value
      )

    if (!currentOrderStillExists) {
      const activeOrder =
        manufacturingOrders.value.find(
          order =>
            order.status ===
              'released' ||
            order.status ===
              'in_progress'
        )

      const firstOrder =
        activeOrder ??
        manufacturingOrders.value[0]

      selectedOrderId.value =
        firstOrder?.id ?? null
    }

    if (
      selectedOrderId.value !== null
    ) {
      await loadOperations(
        selectedOrderId.value
      )
    } else {
      operations.value = []
    }
  } catch (error) {
    console.error(error)

    ElMessage.error(
      'MES 数据加载失败'
    )
  } finally {
    loadingOrders.value = false
  }
}

async function loadOperations(
  manufacturingOrderId: number
) {
  loadingOperations.value = true

  try {
    const response =
      await api.get<
        ManufacturingOperation[]
      >(
        `/manufacturing-orders/${manufacturingOrderId}/operations`
      )

    operations.value =
      response.data
  } catch (error: any) {
    console.error(error)

    operations.value = []

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `工序加载失败：${detail}`
        : '生产工序加载失败'
    )
  } finally {
    loadingOperations.value = false
  }
}

async function handleOrderChange(
  value: number
) {
  await loadOperations(value)
}

/* =========================
   MES 进度
   ========================= */

const totalPlannedQuantity =
  computed(
    () =>
      operations.value.reduce(
        (total, operation) =>
          total +
          Number(
            operation.planned_quantity
          ),
        0
      )
  )

const totalCompletedQuantity =
  computed(
    () =>
      operations.value.reduce(
        (total, operation) =>
          total +
          Number(
            operation.completed_quantity
          ),
        0
      )
  )

const overallProgress = computed(
  () => {
    if (
      totalPlannedQuantity.value <= 0
    ) {
      return 0
    }

    return Math.min(
      100,
      Math.round(
        (
          totalCompletedQuantity.value /
          totalPlannedQuantity.value
        ) * 100
      )
    )
  }
)

const completedOperationCount =
  computed(
    () =>
      operations.value.filter(
        operation =>
          operation.status ===
          'completed'
      ).length
  )

/* =========================
   报工控制
   ========================= */

function canReport(
  operation: ManufacturingOperation
) {
  if (
    operation.status ===
    'completed'
  ) {
    return false
  }

  if (
    !selectedOrder.value ||
    (
      selectedOrder.value.status !==
        'released' &&
      selectedOrder.value.status !==
        'in_progress'
    )
  ) {
    return false
  }

  const previousOperations =
    operations.value.filter(
      item =>
        item.sequence <
        operation.sequence
    )

  return previousOperations.every(
    item =>
      item.status ===
      'completed'
  )
}

function openReportDialog(
  operation: ManufacturingOperation
) {
  const remaining =
    Math.max(
      0,
      Number(
        operation.planned_quantity
      ) -
      Number(
        operation.completed_quantity
      )
    )

  reportingOperation.value =
    operation

  reportForm.value = {
    operator_name: '',
    good_quantity: remaining,
    defect_quantity: 0,
    remark: '',
  }

  reportDialogVisible.value = true
}

async function submitProductionReport() {
  if (
    reportingOperation.value === null
  ) {
    return
  }

  if (
    !reportForm.value.operator_name.trim()
  ) {
    ElMessage.warning(
      '请输入操作员'
    )

    return
  }

  if (
    reportForm.value.good_quantity <= 0
  ) {
    ElMessage.warning(
      '合格数量必须大于 0'
    )

    return
  }

  const remaining =
    Number(
      reportingOperation.value
        .planned_quantity
    ) -
    Number(
      reportingOperation.value
        .completed_quantity
    )

  if (
    reportForm.value.good_quantity >
    remaining
  ) {
    ElMessage.warning(
      `合格数量不能超过剩余数量 ${remaining.toFixed(3)}`
    )

    return
  }

  if (
    reportForm.value.defect_quantity <
    0
  ) {
    ElMessage.warning(
      '不良数量不能小于 0'
    )

    return
  }

  reportSaving.value = true

  try {
    await api.post(
      `/manufacturing-operations/${reportingOperation.value.id}/reports`,
      {
        operator_name:
          reportForm.value
            .operator_name.trim(),

        good_quantity:
          reportForm.value
            .good_quantity,

        defect_quantity:
          reportForm.value
            .defect_quantity,

        remark:
          reportForm.value
            .remark.trim() ||
          null,
      }
    )

    ElMessage.success(
      `${getOperationName(reportingOperation.value)} 报工成功`
    )

    reportDialogVisible.value =
      false

    reportingOperation.value =
      null

    await loadData()
  } catch (error: any) {
    console.error(error)

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `报工失败：${detail}`
        : '生产报工失败'
    )
  } finally {
    reportSaving.value = false
  }
}

/* =========================
   显示辅助
   ========================= */

function getOperationName(
  operation: ManufacturingOperation
) {
  return (
    operation.operation_name ||
    operation.name ||
    `工序 ${operation.sequence}`
  )
}

function getProductName(
  productId: number
) {
  const product =
    products.value.find(
      item =>
        item.id === productId
    )

  if (!product) {
    return `产品 #${productId}`
  }

  return (
    `${product.code} / ` +
    `${product.name}`
  )
}

function getOrderStatusText(
  status: string
) {
  const statusMap:
    Record<string, string> = {
      planned: '计划中',
      released: '已下达',
      in_progress: '生产中',
      completed: '已完成',
      received: '已入库',
    }

  return statusMap[status] ?? status
}

function getOrderStatusType(
  status: string
): TagType {
  const statusMap:
    Record<string, TagType> = {
      planned: 'info',
      released: 'primary',
      in_progress: 'warning',
      completed: 'success',
      received: 'success',
    }

  return statusMap[status] ?? 'info'
}

function getOperationStatusText(
  status: string
) {
  const statusMap:
    Record<string, string> = {
      pending: '待生产',
      in_progress: '生产中',
      completed: '已完成',
    }

  return statusMap[status] ?? status
}

function getOperationStatusType(
  status: string
): TagType {
  const statusMap:
    Record<string, TagType> = {
      pending: 'info',
      in_progress: 'warning',
      completed: 'success',
    }

  return statusMap[status] ?? 'info'
}

function formatQuantity(
  value: number | string
) {
  return Number(value).toFixed(3)
}

function getProgress(
  operation: ManufacturingOperation
) {
  const planned =
    Number(
      operation.planned_quantity
    )

  const completed =
    Number(
      operation.completed_quantity
    )

  if (planned <= 0) {
    return 0
  }

  return Math.min(
    100,
    Math.round(
      (completed / planned) * 100
    )
  )
}

function getOperationActionText(
  operation: ManufacturingOperation
) {
  if (
    operation.status ===
    'completed'
  ) {
    return '工序已完成'
  }

  if (canReport(operation)) {
    return '报工'
  }

  return '等待前工序'
}

onMounted(() => {
  loadData()
})
</script>

<template>
  <div class="mes-page">
    <!-- 页面标题 -->
    <div class="business-page-header">
      <div>
        <h1>MES 生产执行</h1>

        <p>
          查看生产订单工序进度并执行现场生产报工
        </p>
      </div>

      <div class="business-page-actions">
        <el-button
          :icon="Refresh"
          :loading="
            loadingOrders ||
            loadingOperations
          "
          @click="loadData"
        >
          刷新
        </el-button>
      </div>
    </div>

    <!-- 生产订单选择 -->
    <el-card
      shadow="never"
      class="mes-order-card"
    >
      <div class="mes-order-toolbar">
        <div class="order-selector">
          <span>生产订单</span>

          <el-select
            v-model="
              selectedOrderId
            "
            placeholder="请选择生产订单"
            filterable
            style="width: 320px"
            @change="
              handleOrderChange
            "
          >
            <el-option
              v-for="
                order
                in manufacturingOrders
              "
              :key="order.id"
              :label="order.order_no"
              :value="order.id"
            >
              <div
                class="order-option"
              >
                <span>
                  {{ order.order_no }}
                </span>

                <el-tag
                  :type="
                    getOrderStatusType(
                      order.status
                    )
                  "
                  size="small"
                  effect="light"
                >
                  {{
                    getOrderStatusText(
                      order.status
                    )
                  }}
                </el-tag>
              </div>
            </el-option>
          </el-select>
        </div>

        <div
          v-if="selectedOrder"
          class="order-selected-status"
        >
          <el-tag
            :type="
              getOrderStatusType(
                selectedOrder.status
              )
            "
            effect="light"
            round
          >
            {{
              getOrderStatusText(
                selectedOrder.status
              )
            }}
          </el-tag>
        </div>
      </div>

      <template
        v-if="selectedOrder"
      >
        <el-divider />

        <div class="mes-order-summary">
          <div class="order-summary-main">
            <div
              class="order-summary-icon"
            >
              <el-icon>
                <Tickets />
              </el-icon>
            </div>

            <div>
              <span>
                当前生产订单
              </span>

              <strong>
                {{
                  selectedOrder.order_no
                }}
              </strong>
            </div>
          </div>

          <div class="order-summary-item">
            <span>产品</span>

            <strong>
              {{
                getProductName(
                  selectedOrder.product_id
                )
              }}
            </strong>
          </div>

          <div class="order-summary-item">
            <span>计划数量</span>

            <strong>
              {{
                formatQuantity(
                  selectedOrder
                    .planned_quantity
                )
              }}
            </strong>
          </div>

          <div class="order-summary-item">
            <span>工序完成</span>

            <strong>
              {{
                completedOperationCount
              }}
              /
              {{
                operations.length
              }}
            </strong>
          </div>
        </div>

        <div
          v-if="
            operations.length > 0
          "
          class="overall-progress"
        >
          <div
            class="overall-progress-header"
          >
            <span>
              整体工序进度
            </span>

            <strong>
              {{ overallProgress }}%
            </strong>
          </div>

          <el-progress
            :percentage="
              overallProgress
            "
            :stroke-width="10"
            :show-text="false"
          />
        </div>
      </template>
    </el-card>

    <!-- 没有选择订单 -->
    <el-empty
      v-if="
        !loadingOrders &&
        !selectedOrder
      "
      description="暂无生产订单"
      class="mes-empty"
    />

    <!-- 工序加载 -->
    <div
      v-if="
        selectedOrder &&
        loadingOperations
      "
      class="mes-loading"
    >
      <el-skeleton
        :rows="6"
        animated
      />
    </div>

    <!-- 计划中，没有工序 -->
    <el-alert
      v-else-if="
        selectedOrder &&
        selectedOrder.status ===
          'planned' &&
        operations.length === 0
      "
      title="该生产订单尚未下达，因此还没有生成生产工序。请先到“生产订单”页面执行下达生产。"
      type="info"
      show-icon
      :closable="false"
      class="mes-state-alert"
    />

    <!-- 已经有工序 -->
    <div
      v-else-if="
        selectedOrder &&
        operations.length > 0
      "
      class="operations-section"
    >
      <div class="section-heading">
        <div>
          <h2>生产工序</h2>

          <p>
            工序必须按照顺序完成，前一道工序完成后才能进行下一道
          </p>
        </div>

        <div class="operation-count">
          共
          <strong>
            {{ operations.length }}
          </strong>
          道工序
        </div>
      </div>

      <div class="operation-grid">
        <el-card
          v-for="
            operation
            in operations
          "
          :key="operation.id"
          shadow="never"
          class="operation-card"
          :class="{
            'operation-completed':
              operation.status ===
              'completed',

            'operation-current':
              canReport(operation),
          }"
        >
          <div class="operation-card-top">
            <div class="operation-sequence">
              {{
                operation.sequence
              }}
            </div>

            <el-tag
              :type="
                getOperationStatusType(
                  operation.status
                )
              "
              effect="light"
              round
            >
              {{
                getOperationStatusText(
                  operation.status
                )
              }}
            </el-tag>
          </div>

          <div class="operation-name">
            {{
              getOperationName(operation)
            }}
          </div>

          <div class="operation-quantity">
            <strong>
              {{
                formatQuantity(
                  operation
                    .completed_quantity
                )
              }}
            </strong>

            <span>
              /
              {{
                formatQuantity(
                  operation
                    .planned_quantity
                )
              }}
            </span>
          </div>

          <el-progress
            :percentage="
              getProgress(operation)
            "
            :stroke-width="9"
            :status="
              operation.status ===
                'completed'
                ? 'success'
                : undefined
            "
            class="operation-progress"
          />

          <div class="operation-footer">
            <div class="operation-progress-text">
              <el-icon>
                <CircleCheck
                  v-if="
                    operation.status ===
                    'completed'
                  "
                />

                <Clock v-else />
              </el-icon>

              <span>
                完成进度
                {{
                  getProgress(
                    operation
                  )
                }}%
              </span>
            </div>

            <el-button
              v-if="
                operation.status !==
                'completed'
              "
              :type="
                canReport(operation)
                  ? 'primary'
                  : 'info'
              "
              :disabled="
                !canReport(operation) ||
                reportSaving
              "
              @click="
                openReportDialog(
                  operation
                )
              "
            >
              {{
                getOperationActionText(
                  operation
                )
              }}
            </el-button>

            <el-tag
              v-else
              type="success"
              effect="plain"
            >
              工序已完成
            </el-tag>
          </div>
        </el-card>
      </div>
    </div>

    <!-- =======================
         报工 Dialog
         ======================= -->

    <el-dialog
      v-model="
        reportDialogVisible
      "
      title="生产报工"
      width="560px"
      destroy-on-close
    >
      <template
        v-if="
          reportingOperation
        "
      >
        <el-alert
          title="合格数量计入工序完成数量；不良数量仅作为质量记录，不计入完成数量。"
          type="info"
          show-icon
          :closable="false"
          class="report-alert"
        />

        <el-descriptions
          :column="2"
          border
          class="report-description"
        >
          <el-descriptions-item
            label="生产订单"
          >
            {{
              selectedOrder?.order_no
            }}
          </el-descriptions-item>

          <el-descriptions-item
            label="工序"
          >
            {{
              getOperationName(
                reportingOperation
              )
            }}
          </el-descriptions-item>

          <el-descriptions-item
            label="计划数量"
          >
            {{
              formatQuantity(
                reportingOperation
                  .planned_quantity
              )
            }}
          </el-descriptions-item>

          <el-descriptions-item
            label="已完成"
          >
            {{
              formatQuantity(
                reportingOperation
                  .completed_quantity
              )
            }}
          </el-descriptions-item>
        </el-descriptions>

        <el-form
          label-position="top"
          class="report-form"
        >
          <el-form-item
            label="操作员"
            required
          >
            <el-input
              v-model="
                reportForm.operator_name
              "
              placeholder="请输入操作员姓名"
              clearable
            />
          </el-form-item>

          <div class="report-number-grid">
            <el-form-item
              label="本次合格数量"
              required
            >
              <el-input-number
                v-model="
                  reportForm.good_quantity
                "
                :min="0"
                :precision="3"
                :step="1"
                controls-position="right"
                style="width: 100%"
              />
            </el-form-item>

            <el-form-item
              label="本次不良数量"
            >
              <el-input-number
                v-model="
                  reportForm.defect_quantity
                "
                :min="0"
                :precision="3"
                :step="1"
                controls-position="right"
                style="width: 100%"
              />
            </el-form-item>
          </div>

          <el-form-item
            label="备注"
          >
            <el-input
              v-model="
                reportForm.remark
              "
              type="textarea"
              :rows="3"
              placeholder="例如：本工序生产完成"
            />
          </el-form-item>
        </el-form>
      </template>

      <template #footer>
        <div class="dialog-footer">
          <el-button
            :disabled="
              reportSaving
            "
            @click="
              reportDialogVisible =
                false
            "
          >
            取消
          </el-button>

          <el-button
            type="primary"
            :loading="
              reportSaving
            "
            @click="
              submitProductionReport
            "
          >
            提交报工
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.mes-page {
  width: 100%;
}

.business-page-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  gap: 20px;
  margin-bottom: 22px;
}

.business-page-header h1 {
  margin: 0;

  color: #172033;
  font-size: 28px;
  font-weight: 700;
}

.business-page-header p {
  margin: 7px 0 0;

  color: #8a94a5;
  font-size: 14px;
}

.business-page-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

/* 当前生产订单 */

.mes-order-card {
  margin-bottom: 24px;

  border-radius: 12px;
  border: 1px solid #e7ebf0;
}

.mes-order-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;

  gap: 20px;
}

.order-selector {
  display: flex;
  align-items: center;
  gap: 14px;
}

.order-selector > span {
  color: #596579;
  font-size: 13px;
  font-weight: 600;
}

.order-option {
  width: 100%;

  display: flex;
  align-items: center;
  justify-content: space-between;
}

.mes-order-summary {
  display: grid;

  grid-template-columns:
    1.3fr
    1.5fr
    0.8fr
    0.8fr;

  gap: 26px;
  align-items: center;
}

.order-summary-main {
  display: flex;
  align-items: center;
  gap: 13px;
}

.order-summary-icon {
  width: 44px;
  height: 44px;

  display: flex;
  align-items: center;
  justify-content: center;

  flex-shrink: 0;

  border-radius: 11px;

  color: #2c7be5;
  background: #edf4ff;

  font-size: 21px;
}

.order-summary-main > div:last-child,
.order-summary-item {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.order-summary-main span,
.order-summary-item span {
  color: #9099a8;
  font-size: 12px;
}

.order-summary-main strong,
.order-summary-item strong {
  color: #253044;
  font-size: 15px;
}

.overall-progress {
  margin-top: 24px;
}

.overall-progress-header {
  display: flex;
  align-items: center;
  justify-content: space-between;

  margin-bottom: 8px;

  color: #657186;
  font-size: 12px;
}

.overall-progress-header strong {
  color: #2c7be5;
}

/* 工序区域 */

.operations-section {
  margin-top: 2px;
}

.section-heading {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;

  margin-bottom: 16px;
}

.section-heading h2 {
  margin: 0;

  color: #172033;
  font-size: 19px;
}

.section-heading p {
  margin: 5px 0 0;

  color: #929baa;
  font-size: 12px;
}

.operation-count {
  color: #8a94a5;
  font-size: 12px;
}

.operation-count strong {
  color: #2c7be5;
}

.operation-grid {
  display: grid;

  grid-template-columns:
    repeat(
      2,
      minmax(0, 1fr)
    );

  gap: 18px;
}

.operation-card {
  border-radius: 12px;
  border: 1px solid #e7ebf0;

  transition:
    border-color 0.2s ease,
    box-shadow 0.2s ease,
    transform 0.2s ease;
}

.operation-card:hover {
  transform: translateY(-1px);

  box-shadow:
    0 6px 20px
    rgba(23, 32, 51, 0.06);
}

.operation-current {
  border-color: #9dc6ff;
}

.operation-completed {
  background: #fbfefc;
}

.operation-card-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.operation-sequence {
  width: 34px;
  height: 34px;

  display: flex;
  align-items: center;
  justify-content: center;

  border-radius: 50%;

  color: #2c7be5;
  background: #edf4ff;

  font-size: 13px;
  font-weight: 700;
}

.operation-completed
.operation-sequence {
  color: #3b9d64;
  background: #ebf8f0;
}

.operation-name {
  margin-top: 18px;

  color: #172033;
  font-size: 21px;
  font-weight: 700;
}

.operation-quantity {
  display: flex;
  align-items: baseline;
  gap: 5px;

  margin-top: 14px;
}

.operation-quantity strong {
  color: #172033;
  font-size: 25px;
}

.operation-quantity span {
  color: #98a1af;
  font-size: 14px;
}

.operation-progress {
  margin-top: 14px;
}

.operation-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;

  gap: 15px;

  margin-top: 18px;
}

.operation-progress-text {
  display: flex;
  align-items: center;
  gap: 6px;

  color: #8791a1;
  font-size: 12px;
}

/* 报工 */

.report-alert {
  margin-bottom: 18px;
}

.report-description {
  margin-bottom: 20px;
}

.report-form {
  margin-top: 2px;
}

.report-number-grid {
  display: grid;

  grid-template-columns:
    repeat(
      2,
      minmax(0, 1fr)
    );

  gap: 16px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

.mes-empty,
.mes-loading,
.mes-state-alert {
  margin-top: 20px;
}

@media (max-width: 1000px) {
  .mes-order-summary {
    grid-template-columns:
      repeat(
        2,
        minmax(0, 1fr)
      );
  }
}

@media (max-width: 760px) {
  .business-page-header,
  .mes-order-toolbar,
  .section-heading {
    flex-direction: column;
    align-items: stretch;
  }

  .order-selector {
    flex-direction: column;
    align-items: stretch;
  }

  .operation-grid,
  .mes-order-summary,
  .report-number-grid {
    grid-template-columns: 1fr;
  }
}
</style>
