<script setup lang="ts">
import {
  computed,
  onMounted,
  ref,
} from 'vue'

import {
  Delete,
  Plus,
  Refresh,
} from '@element-plus/icons-vue'

import {
  ElMessage,
} from 'element-plus'

import api from '../services/api'

interface Product {
  id: number
  code: string
  name: string
  unit: string
  active: boolean
}

interface RoutingOperation {
  id: number
  sequence: number
  operation_name: string
}

interface Routing {
  id: number
  product_id: number
  name: string
  active: boolean
  operations: RoutingOperation[]
}

interface RoutingFormOperation {
  sequence: number
  operation_name: string
}

const routings = ref<Routing[]>([])
const products = ref<Product[]>([])

const loading = ref(false)
const saving = ref(false)

const createDialogVisible =
  ref(false)

const routingForm = ref({
  product_id: null as number | null,
  name: '',
  operations: [
    {
      sequence: 10,
      operation_name: '',
    },
  ] as RoutingFormOperation[],
})

/* =========================
   产品
   ========================= */

const availableProducts = computed(
  () => {
    const usedProductIds =
      new Set(
        routings.value.map(
          routing =>
            routing.product_id
        )
      )

    return products.value.filter(
      product =>
        product.active &&
        !usedProductIds.has(
          product.id
        )
    )
  }
)

/* =========================
   加载数据
   ========================= */

async function loadData() {
  loading.value = true

  try {
    const [
      routingResponse,
      productResponse,
    ] = await Promise.all([
      api.get<Routing[]>(
        '/routings'
      ),

      api.get<Product[]>(
        '/products'
      ),
    ])

    routings.value =
      routingResponse.data

    products.value =
      productResponse.data
  } catch (error) {
    console.error(error)

    ElMessage.error(
      '工艺路线数据加载失败'
    )
  } finally {
    loading.value = false
  }
}

/* =========================
   新建 Routing
   ========================= */

function openCreateDialog() {
  routingForm.value = {
    product_id: null,
    name: '',
    operations: [
      {
        sequence: 10,
        operation_name: '',
      },
    ],
  }

  createDialogVisible.value =
    true
}

function addOperation() {
  const operations =
    routingForm.value.operations

  const maxSequence =
    operations.length > 0
      ? Math.max(
          ...operations.map(
            item => item.sequence
          )
        )
      : 0

  operations.push({
    sequence:
      maxSequence + 10,
    operation_name: '',
  })
}

function removeOperation(
  index: number
) {
  if (
    routingForm.value.operations
      .length <= 1
  ) {
    ElMessage.warning(
      '工艺路线至少需要一道工序'
    )

    return
  }

  routingForm.value.operations.splice(
    index,
    1
  )
}

async function createRouting() {
  if (
    routingForm.value.product_id ===
    null
  ) {
    ElMessage.warning(
      '请选择产品'
    )

    return
  }

  if (
    !routingForm.value.name.trim()
  ) {
    ElMessage.warning(
      '请输入工艺路线名称'
    )

    return
  }

  if (
    routingForm.value.operations
      .length === 0
  ) {
    ElMessage.warning(
      '至少需要一道生产工序'
    )

    return
  }

  const sequences =
    routingForm.value.operations.map(
      operation =>
        operation.sequence
    )

  if (
    new Set(sequences).size !==
    sequences.length
  ) {
    ElMessage.warning(
      '工序顺序不能重复'
    )

    return
  }

  for (
    const operation
    of routingForm.value.operations
  ) {
    if (
      operation.sequence <= 0
    ) {
      ElMessage.warning(
        '工序顺序必须大于 0'
      )

      return
    }

    if (
      !operation.operation_name
        .trim()
    ) {
      ElMessage.warning(
        '工序名称不能为空'
      )

      return
    }
  }

  saving.value = true

  try {
    await api.post(
      '/routings',
      {
        product_id:
          routingForm.value
            .product_id,

        name:
          routingForm.value
            .name.trim(),

        operations:
          routingForm.value.operations
            .map(operation => ({
              sequence:
                operation.sequence,

              operation_name:
                operation
                  .operation_name
                  .trim(),
            })),
      }
    )

    ElMessage.success(
      '工艺路线创建成功'
    )

    createDialogVisible.value =
      false

    await loadData()
  } catch (error: any) {
    console.error(error)

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `创建失败：${detail}`
        : '工艺路线创建失败'
    )
  } finally {
    saving.value = false
  }
}

/* =========================
   显示辅助
   ========================= */

function getProductName(
  productId: number
) {
  const product =
    products.value.find(
      item =>
        item.id === productId
    )

  if (!product) {
    return `产品 #${productId}`
  }

  return (
    `${product.code} / ` +
    `${product.name}`
  )
}

function getProductUnit(
  productId: number
) {
  const product =
    products.value.find(
      item =>
        item.id === productId
    )

  return product?.unit ?? ''
}

onMounted(() => {
  loadData()
})
</script>

<template>
  <div class="routing-page">
    <!-- 页面标题 -->
    <div class="business-page-header">
      <div>
        <h1>工艺路线</h1>

        <p>
          维护产品生产工序模板，
          生产订单下达时自动生成 MES 工序
        </p>
      </div>

      <div class="business-page-actions">
        <el-button
          :icon="Refresh"
          :loading="loading"
          @click="loadData"
        >
          刷新
        </el-button>

        <el-button
          type="primary"
          :icon="Plus"
          @click="openCreateDialog"
        >
          新增工艺路线
        </el-button>
      </div>
    </div>

    <!-- Routing 列表 -->
    <div
      v-loading="loading"
      class="routing-grid"
    >
      <el-card
        v-for="
          routing in routings
        "
        :key="routing.id"
        shadow="never"
        class="routing-card"
      >
        <div class="routing-card-header">
          <div>
            <span class="routing-label">
              工艺路线
            </span>

            <h2>
              {{ routing.name }}
            </h2>
          </div>

          <el-tag
            :type="
              routing.active
                ? 'success'
                : 'info'
            "
            effect="light"
            round
          >
            {{
              routing.active
                ? '启用'
                : '停用'
            }}
          </el-tag>
        </div>

        <div class="routing-product">
          <span>产品</span>

          <strong>
            {{
              getProductName(
                routing.product_id
              )
            }}
          </strong>

          <small>
            单位：
            {{
              getProductUnit(
                routing.product_id
              )
            }}
          </small>
        </div>

        <el-divider />

        <div class="routing-operation-title">
          <span>生产工序</span>

          <small>
            共
            {{
              routing.operations.length
            }}
            道
          </small>
        </div>

        <div class="routing-operation-list">
          <div
            v-for="
              operation
              in routing.operations
            "
            :key="operation.id"
            class="routing-operation"
          >
            <div class="operation-sequence">
              {{ operation.sequence }}
            </div>

            <div class="operation-line"></div>

            <div class="operation-name">
              {{
                operation.operation_name
              }}
            </div>
          </div>
        </div>
      </el-card>

      <el-empty
        v-if="
          !loading &&
          routings.length === 0
        "
        description="暂无工艺路线"
        class="routing-empty"
      />
    </div>

    <!-- =======================
         新建工艺路线
         ======================= -->

    <el-dialog
      v-model="createDialogVisible"
      title="新增工艺路线"
      width="720px"
      destroy-on-close
    >
      <el-form
        label-position="top"
      >
        <div class="routing-basic-grid">
          <el-form-item
            label="产品"
            required
          >
            <el-select
              v-model="
                routingForm.product_id
              "
              placeholder="请选择产品"
              filterable
              style="width: 100%"
            >
              <el-option
                v-for="
                  product
                  in availableProducts
                "
                :key="product.id"
                :label="
                  `${product.code} / ${product.name}`
                "
                :value="product.id"
              />
            </el-select>
          </el-form-item>

          <el-form-item
            label="工艺路线名称"
            required
          >
            <el-input
              v-model="
                routingForm.name
              "
              placeholder="例如 高效电机标准工艺"
              clearable
            />
          </el-form-item>
        </div>

        <div class="operation-form-header">
          <div>
            <strong>
              生产工序
            </strong>

            <span>
              按 sequence 从小到大执行
            </span>
          </div>

          <el-button
            type="primary"
            plain
            :icon="Plus"
            @click="addOperation"
          >
            添加工序
          </el-button>
        </div>

        <div
          v-for="
            (operation, index)
            in routingForm.operations
          "
          :key="index"
          class="operation-form-row"
        >
          <div class="operation-form-index">
            {{ index + 1 }}
          </div>

          <div>
            <label>
              工序顺序
            </label>

            <el-input-number
              v-model="
                operation.sequence
              "
              :min="1"
              :precision="0"
              :step="10"
              controls-position="right"
              style="width: 100%"
            />
          </div>

          <div>
            <label>
              工序名称
            </label>

            <el-input
              v-model="
                operation.operation_name
              "
              placeholder="例如 绕线"
              clearable
            />
          </div>

          <div class="operation-delete">
            <el-button
              circle
              plain
              type="danger"
              :icon="Delete"
              @click="
                removeOperation(index)
              "
            />
          </div>
        </div>
      </el-form>

      <template #footer>
        <div class="dialog-footer">
          <el-button
            :disabled="saving"
            @click="
              createDialogVisible =
                false
            "
          >
            取消
          </el-button>

          <el-button
            type="primary"
            :loading="saving"
            @click="createRouting"
          >
            创建工艺路线
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.routing-page {
  width: 100%;
}

.business-page-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  gap: 20px;
  margin-bottom: 22px;
}

.business-page-header h1 {
  margin: 0;

  color: #172033;

  font-size: 28px;
  font-weight: 700;
}

.business-page-header p {
  margin: 7px 0 0;

  color: #8a94a5;
  font-size: 14px;
}

.business-page-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

/* Routing 卡片 */

.routing-grid {
  display: grid;

  grid-template-columns:
    repeat(
      2,
      minmax(0, 1fr)
    );

  gap: 18px;
}

.routing-card {
  border-radius: 12px;

  border:
    1px solid #e7ebf0;
}

.routing-card-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  gap: 20px;
}

.routing-label {
  color: #949dac;
  font-size: 11px;
}

.routing-card-header h2 {
  margin: 5px 0 0;

  color: #172033;
  font-size: 19px;
}

.routing-product {
  display: flex;
  flex-direction: column;

  gap: 4px;

  margin-top: 20px;

  padding: 14px 16px;

  border-radius: 9px;

  background: #f7f9fc;
}

.routing-product span {
  color: #929baa;
  font-size: 11px;
}

.routing-product strong {
  color: #2c7be5;
  font-size: 14px;
}

.routing-product small {
  color: #9aa3b1;
}

.routing-operation-title {
  display: flex;
  align-items: center;
  justify-content: space-between;

  margin-bottom: 14px;
}

.routing-operation-title span {
  color: #354052;
  font-weight: 700;
}

.routing-operation-title small {
  color: #929baa;
}

.routing-operation-list {
  display: flex;
  flex-direction: column;
}

.routing-operation {
  min-height: 46px;

  display: grid;

  grid-template-columns:
    42px
    3px
    1fr;

  gap: 13px;

  align-items: center;
}

.operation-sequence {
  width: 38px;
  height: 30px;

  display: flex;
  align-items: center;
  justify-content: center;

  border-radius: 8px;

  color: #2c7be5;
  background: #edf4ff;

  font-size: 12px;
  font-weight: 700;
}

.operation-line {
  width: 3px;
  height: 100%;

  border-radius: 3px;

  background: #e1e8f1;
}

.operation-name {
  color: #303846;
  font-weight: 600;
}

.routing-empty {
  grid-column: 1 / -1;
}

/* Dialog */

.routing-basic-grid {
  display: grid;

  grid-template-columns:
    repeat(
      2,
      minmax(0, 1fr)
    );

  gap: 18px;
}

.operation-form-header {
  display: flex;
  align-items: center;
  justify-content: space-between;

  margin: 6px 0 14px;
}

.operation-form-header > div {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.operation-form-header strong {
  color: #303846;
}

.operation-form-header span {
  color: #949dac;
  font-size: 11px;
}

.operation-form-row {
  display: grid;

  grid-template-columns:
    34px
    150px
    1fr
    40px;

  gap: 12px;

  align-items: end;

  padding: 13px;

  margin-bottom: 10px;

  border:
    1px solid #e8edf3;

  border-radius: 9px;

  background: #f8fafc;
}

.operation-form-row > div {
  min-width: 0;
}

.operation-form-row label {
  display: block;

  margin-bottom: 6px;

  color: #687386;
  font-size: 11px;
}

.operation-form-index {
  height: 32px;

  display: flex;
  align-items: center;
  justify-content: center;

  color: #8d97a7;
}

.operation-delete {
  height: 32px;

  display: flex;
  align-items: center;
  justify-content: center;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

@media (max-width: 900px) {
  .routing-grid,
  .routing-basic-grid {
    grid-template-columns: 1fr;
  }

  .business-page-header {
    flex-direction: column;
  }

  .operation-form-row {
    grid-template-columns: 1fr;
  }
}
</style>