<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Refresh, Plus } from '@element-plus/icons-vue'
import { isAxiosError } from 'axios'
import api from '../services/api'

interface Warehouse { id: number; code: string; name: string; active: boolean }
interface Product { id: number; code: string; name: string; unit: string; active: boolean }
interface Stock { warehouse_id: number; product_id: number; on_hand_quantity: string; available_quantity: string }
interface Receipt { receipt_id: number; receipt_quantity: string; on_hand_quantity: string; reserved_quantity: string; available_quantity: string }
const router = useRouter(), warehouses = ref<Warehouse[]>([]), products = ref<Product[]>([]), stock = ref<Stock[]>([])
const loading = ref(false), saving = ref(false), creating = ref(false), error = ref(''), tab = ref('receipt'), warehouseDialog = ref(false)
const warehouseForm = reactive({ code: '', name: '' })
const form = reactive({ warehouse_id: undefined as number | undefined, product_id: undefined as number | undefined, quantity: 1, remark: '' })
const result = ref<{ data: Receipt; warehouse: string; product: string; unit: string }>()
const activeWarehouses = computed(() => warehouses.value.filter(item => item.active))
const activeProducts = computed(() => products.value.filter(item => item.active))
const currentProduct = computed(() => products.value.find(item => item.id === form.product_id))
const currentStock = computed(() => stock.value.find(item => item.warehouse_id === form.warehouse_id && item.product_id === form.product_id))
const format = (value: unknown) => Number(value ?? 0).toLocaleString('zh-CN', { maximumFractionDigits: 3 })
/** 将业务接口错误转为可阅读的提示，不展示内部堆栈。 */
function messageFor(cause: unknown, fallback: string): string {
  return isAxiosError(cause) && typeof cause.response?.data?.detail === 'string' ? cause.response.data.detail : fallback
}
/** 同步仓库、产品和库存，表单仅显示可使用的基础资料。 */
async function loadData(): Promise<void> {
  loading.value = true; error.value = ''
  try {
    const [w, p, s] = await Promise.all([api.get<Warehouse[]>('/warehouses'), api.get<Product[]>('/products'), api.get<Stock[]>('/inventory')])
    warehouses.value = w.data; products.value = p.data; stock.value = s.data
    if (form.warehouse_id === undefined) form.warehouse_id = activeWarehouses.value[0]?.id
  } catch { error.value = '基础数据加载失败，请检查服务并刷新后再提交。' }
  finally { loading.value = false }
}
/** 新建仓库后立即选中它，方便继续办理入库。 */
async function createWarehouse(): Promise<void> {
  if (creating.value) return
  const code = warehouseForm.code.trim(), name = warehouseForm.name.trim()
  if (!code || !name) { ElMessage.warning('请填写仓库编码和名称。'); return }
  creating.value = true
  try {
    const response = await api.post<Warehouse>('/warehouses', { code, name })
    warehouses.value.push(response.data); form.warehouse_id = response.data.id
    warehouseDialog.value = false; warehouseForm.code = ''; warehouseForm.name = ''
    ElMessage.success('仓库已创建，可继续办理入库。')
  } catch (cause) { ElMessage.error(messageFor(cause, '创建失败，请检查服务后重试。')) }
  finally { creating.value = false }
}
/** 提交其他入库；成功后保留回执，清空本次数量和备注，防止误重复。 */
async function submitReceipt(): Promise<void> {
  if (saving.value || loading.value || error.value) return
  const warehouse = activeWarehouses.value.find(item => item.id === form.warehouse_id), product = currentProduct.value
  if (!warehouse || !product?.active || !Number.isFinite(form.quantity) || form.quantity <= 0) {
    ElMessage.warning('请选择有效仓库、产品，并填写大于零的入库数量。'); return
  }
  saving.value = true
  try {
    const response = await api.post<Receipt>('/inventory/receipts', { ...form, remark: form.remark.trim() || null })
    result.value = { data: response.data, warehouse: warehouse.name, product: product.name, unit: product.unit }
    form.quantity = 0; form.remark = ''
    ElMessage.success('入库成功，库存和流水已同步。'); await loadData()
  } catch (cause) { ElMessage.error(messageFor(cause, '未能确认入库结果，请先查看库存流水，避免重复提交。')) }
  finally { saving.value = false }
}
onMounted(loadData)
</script>

<template>
  <div class="warehouse-page">
    <header class="warehouse-header"><div><h1>仓库与入库</h1><p>维护仓库基础资料，办理其他入库并查看处理结果。</p></div><el-button :icon="Refresh" :loading="loading" @click="loadData">刷新</el-button></header>
    <el-alert v-if="error" :title="error" type="error" :closable="false" show-icon />
    <div class="warehouse-metrics">
      <el-card shadow="never"><span>仓库总数</span><strong>{{ warehouses.length }}</strong><small>统一维护仓库编码与名称</small></el-card>
      <el-card shadow="never"><span>启用仓库</span><strong>{{ activeWarehouses.length }}</strong><small>可用于入库及订单分配</small></el-card>
      <el-card shadow="never"><span>可入库产品</span><strong>{{ activeProducts.length }}</strong><small>仅显示已启用的产品资料</small></el-card>
    </div>
    <el-card shadow="never" class="warehouse-panel" v-loading="loading">
      <el-tabs v-model="tab">
        <el-tab-pane label="其他入库" name="receipt">
          <div class="receipt-grid">
            <el-form label-position="top" class="receipt-form" @submit.prevent="submitReceipt">
              <div class="warehouse-section-title"><h2>填写入库信息</h2><el-button :icon="Plus" link type="primary" @click="warehouseDialog = true">新建仓库</el-button></div>
              <el-form-item label="入库仓库" required><el-select v-model="form.warehouse_id" placeholder="选择入库仓库" aria-label="入库仓库" :disabled="saving" filterable><el-option v-for="item in activeWarehouses" :key="item.id" :value="item.id" :label="`${item.name} · ${item.code}`" /></el-select></el-form-item>
              <el-form-item label="入库产品" required><el-select v-model="form.product_id" placeholder="搜索产品名称或编码" aria-label="入库产品" :disabled="saving" filterable><el-option v-for="item in activeProducts" :key="item.id" :value="item.id" :label="`${item.name} · ${item.code}`" /></el-select></el-form-item>
              <el-form-item label="入库数量" required><div class="quantity-field"><el-input-number v-model="form.quantity" :min="0" :max="999999999" :precision="3" :disabled="saving" aria-label="入库数量" /><span>{{ currentProduct?.unit ?? '请先选择产品' }}</span></div></el-form-item>
              <el-form-item label="入库备注"><el-input v-model="form.remark" type="textarea" :rows="2" :maxlength="200" show-word-limit placeholder="例如：演示补料、调入或样品入库" :disabled="saving" /></el-form-item>
              <el-button type="primary" native-type="submit" :loading="saving" :disabled="loading || !!error || !form.product_id || !form.warehouse_id || !form.quantity">确认入库</el-button>
            </el-form>
            <aside class="receipt-side">
              <h2>当前库存</h2><p>{{ currentProduct?.name ?? '选择仓库和产品后查看' }}</p>
              <div class="stock-pair"><span>现有库存</span><strong>{{ format(currentStock?.on_hand_quantity) }} {{ currentProduct?.unit }}</strong></div>
              <div class="stock-pair"><span>可用库存</span><strong>{{ format(currentStock?.available_quantity) }} {{ currentProduct?.unit }}</strong></div>
              <p class="receipt-note">其他入库会增加现有库存并生成流水；不会自动分配到销售订单。生产完工请在生产订单中办理入库。</p>
              <template v-if="result">
                <el-tag type="success" effect="light">最近一次入库成功 · 记录 ID {{ result.data.receipt_id }}</el-tag>
                <h3>{{ result.product }}</h3><p>{{ result.warehouse }}</p>
                <div class="stock-pair"><span>本次入库</span><strong>{{ format(result.data.receipt_quantity) }} {{ result.unit }}</strong></div>
                <div class="stock-pair"><span>入库后现有库存</span><strong>{{ format(result.data.on_hand_quantity) }} {{ result.unit }}</strong></div>
                <div class="stock-pair"><span>入库后可用库存</span><strong>{{ format(result.data.available_quantity) }} {{ result.unit }}</strong></div>
                <small>以上是该次提交的回执，不随表单选择变化。</small>
              </template>
              <el-button class="flow-link" @click="router.push('/inventory-transactions')">查看库存流水 →</el-button>
            </aside>
          </div>
        </el-tab-pane>
        <el-tab-pane label="仓库资料" name="warehouses">
          <div class="warehouse-section-title"><h2>仓库列表 <small>共 {{ warehouses.length }} 个</small></h2><el-button type="primary" :icon="Plus" @click="warehouseDialog = true">新建仓库</el-button></div>
          <el-table :data="warehouses" stripe>
            <el-table-column prop="code" label="仓库编码" min-width="170" /><el-table-column prop="name" label="仓库名称" min-width="200" />
            <el-table-column label="状态" width="130"><template #default="{ row }"><el-tag :type="row.active ? 'success' : 'info'">{{ row.active ? '启用' : '停用' }}</el-tag></template></el-table-column>
            <el-table-column label="操作" width="150"><template #default="{ row }"><el-button link type="primary" :disabled="!row.active" @click="form.warehouse_id = row.id; tab = 'receipt'">办理入库</el-button></template></el-table-column>
            <template #empty><el-empty description="暂无仓库，点击新建仓库开始" /></template>
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </el-card>
    <el-dialog v-model="warehouseDialog" title="新建仓库" width="min(460px, 94vw)" :close-on-click-modal="false" :close-on-press-escape="!creating" :show-close="!creating">
      <el-form label-position="top" @submit.prevent="createWarehouse">
        <el-form-item label="仓库编码" required><el-input v-model="warehouseForm.code" :maxlength="50" placeholder="例如 DEMO-WH-01" :disabled="creating" /></el-form-item>
        <el-form-item label="仓库名称" required><el-input v-model="warehouseForm.name" :maxlength="100" placeholder="例如 演示成品仓" :disabled="creating" /></el-form-item>
        <div class="dialog-actions"><el-button :disabled="creating" @click="warehouseDialog = false">取消</el-button><el-button type="primary" native-type="submit" :loading="creating">保存仓库</el-button></div>
      </el-form>
    </el-dialog>
  </div>
</template>

<style scoped>
.warehouse-header,.warehouse-section-title,.stock-pair{display:flex;align-items:center;justify-content:space-between;gap:16px}.warehouse-header{margin-bottom:20px}.warehouse-header h1{margin:0;font-size:28px;color:#172033}.warehouse-header p{margin:7px 0 0;color:#687386;font-size:14px}
.warehouse-metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin:20px 0}.warehouse-metrics .el-card{border-radius:12px;border-top:3px solid #327be4}.warehouse-metrics .el-card:nth-child(2){border-top-color:#24a395}.warehouse-metrics span,.warehouse-metrics small{display:block;color:#687386}.warehouse-metrics strong{display:block;font-size:30px;margin:12px 0;color:#172033}
.warehouse-panel{border-radius:12px}.receipt-grid{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(300px,1fr);gap:32px;padding:16px 0 4px}.warehouse-section-title{margin-bottom:20px}.warehouse-section-title h2,.receipt-side h2{font-size:18px;margin:0;color:#172033}.receipt-form .el-select{width:100%}.quantity-field{display:flex;gap:12px;align-items:center}.quantity-field span,small{font-size:12px;color:#687386}
.receipt-side{background:#f5f8fc;border:1px solid #e6edf6;border-radius:12px;padding:24px}.receipt-side p{color:#687386;font-size:14px}.stock-pair{margin:16px 0;font-size:14px}.stock-pair span{color:#687386}.stock-pair strong{color:#172033}.receipt-note{line-height:1.8;padding:14px 0;border-top:1px solid #e2e8f0}.receipt-side h3{font-size:16px;margin:16px 0 4px}.flow-link{margin-top:20px}.dialog-actions{display:flex;justify-content:flex-end;gap:8px}.warehouse-panel :deep(th.el-table__cell){background:#f5f7fb;color:#5c687a}.warehouse-panel :deep(td.el-table__cell){height:58px}
@media(max-width:800px){.receipt-grid{grid-template-columns:1fr}.warehouse-metrics{grid-template-columns:1fr}.warehouse-header{align-items:flex-start}}
</style>
