<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { Download, Refresh } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import api from '../services/api'

interface Transaction {
  id: number; warehouse_id: number; product_id: number
  transaction_type: string; quantity: string | number
  reference_type: string; reference_id: number; created_at: string
}
interface Master { id: number; code: string; name: string; unit?: string }
const rows = ref<Transaction[]>([]), products = ref<Master[]>([]), warehouses = ref<Master[]>([])
const loading = ref(false), error = ref(''), keyword = ref(''), kind = ref('')
const warehouse = ref<number>(), dates = ref<string[]>([]), page = ref(1)
const selected = ref<Transaction>(), detailOpen = ref(false)
const typeNames: Record<string, string> = { production_receipt: '生产入库', other_receipt: '其他入库' }
const sourceNames: Record<string, string> = { manufacturing_order: '生产订单', inventory_receipt: '其他入库单' }
const product = (id: number) => products.value.find(item => item.id === id)
const warehouseName = (id: number) => warehouses.value.find(item => item.id === id)?.name ?? `仓库 ID ${id}`
const numberText = (value: string | number) => Number(value).toLocaleString('zh-CN', { maximumFractionDigits: 3 })
const timeText = (value: string) => value ? value.replace('T', ' ').slice(0, 19) : '未记录'

/** 读取流水及名称字典；本页面只查询，不修改库存。 */
async function loadData(): Promise<void> {
  loading.value = true; error.value = ''
  try {
    const [transactions, productData, warehouseData] = await Promise.all([
      api.get<Transaction[]>('/inventory/transactions'), api.get<Master[]>('/products'), api.get<Master[]>('/warehouses'),
    ])
    rows.value = transactions.data; products.value = productData.data; warehouses.value = warehouseData.data
  } catch {
    rows.value = []; error.value = '库存流水加载失败，请检查后端服务后重试。'
  } finally { loading.value = false }
}
const kinds = computed(() => [...new Set(rows.value.map(row => row.transaction_type))])
const filtered = computed(() => rows.value.filter(row => {
  const item = product(row.product_id), day = row.created_at?.slice(0, 10) ?? ''
  const query = keyword.value.trim().toLowerCase()
  return (!warehouse.value || row.warehouse_id === warehouse.value) && (!kind.value || row.transaction_type === kind.value)
    && (!dates.value?.length || (day >= dates.value[0]! && day <= dates.value[1]!))
    && (!query || `${item?.code ?? ''} ${item?.name ?? ''} ${row.id} ${row.reference_id}`.toLowerCase().includes(query))
}).sort((a, b) => b.created_at.localeCompare(a.created_at) || b.id - a.id))
const visibleRows = computed(() => filtered.value.slice((page.value - 1) * 15, page.value * 15))
const summary = computed(() => [
  { label: '当前范围流水', value: filtered.value.length, note: '条 · 按实际变动记录统计' },
  { label: '生产入库', value: filtered.value.filter(row => row.transaction_type === 'production_receipt').length, note: '条 · 关联生产订单' },
  { label: '其他入库', value: filtered.value.filter(row => row.transaction_type === 'other_receipt').length, note: '条 · 关联其他入库单' },
])
watch([keyword, kind, warehouse, dates], () => { page.value = 1 })
watch(rows, () => { page.value = 1 })
function resetFilters(): void { keyword.value = ''; kind.value = ''; warehouse.value = undefined; dates.value = [] }
function showDetails(row: Transaction): void { selected.value = row; detailOpen.value = true }
/** 导出当前筛选的全部流水；转义引号并防止文本被表格软件当作公式。 */
function exportCsv(): void {
  try {
    const safeCell = (value: unknown) => {
      const text = String(value ?? ''), safe = /^[=+@\-\t\r]/.test(text) ? `'${text}` : text
      return `"${safe.replaceAll('"', '""')}"`
    }
    const data: unknown[][] = [['流水ID', '记录时间', '仓库', '产品编码', '产品名称', '变动类型', '数量', '单位', '来源类型', '来源记录ID']]
    filtered.value.forEach(row => data.push([row.id, timeText(row.created_at), warehouseName(row.warehouse_id),
      product(row.product_id)?.code, product(row.product_id)?.name, typeNames[row.transaction_type] ?? row.transaction_type,
      row.quantity, product(row.product_id)?.unit, sourceNames[row.reference_type] ?? row.reference_type, row.reference_id]))
    const url = URL.createObjectURL(new Blob(['\uFEFF' + data.map(row => row.map(safeCell).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8;' }))
    const link = document.createElement('a'); link.href = url; link.download = '库存流水.csv'; link.click()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  } catch { ElMessage.error('导出失败，请重试。') }
}
onMounted(loadData)
</script>

<template>
  <div class="transactions-page" v-loading="loading">
    <div class="transaction-header">
      <div><h1>库存流水</h1><p>追查每一次库存变动，从入库记录回到业务来源。</p></div>
      <el-button :icon="Refresh" :loading="loading" @click="loadData">刷新</el-button>
    </div>
    <el-alert v-if="error" :title="error" type="error" show-icon :closable="false" />
    <div class="transaction-summary">
      <el-card v-for="(card, index) in summary" :key="card.label" shadow="never" :class="{ teal: index === 1 }">
        <span>{{ card.label }}</span><strong>{{ card.value }}</strong><small>{{ card.note }}</small>
      </el-card>
    </div>
    <el-card shadow="never" class="transaction-panel">
      <div class="transaction-filters">
        <el-input v-model="keyword" placeholder="产品名称、编码或记录 ID" aria-label="搜索库存流水" clearable />
        <el-select v-model="warehouse" placeholder="全部仓库" aria-label="筛选仓库" clearable>
          <el-option v-for="item in warehouses" :key="item.id" :label="item.name" :value="item.id" />
        </el-select>
        <el-select v-model="kind" placeholder="全部变动类型" aria-label="筛选变动类型" clearable>
          <el-option v-for="item in kinds" :key="item" :label="typeNames[item] ?? item" :value="item" />
        </el-select>
        <el-date-picker v-model="dates" type="daterange" value-format="YYYY-MM-DD" start-placeholder="开始日期" end-placeholder="结束日期" />
        <el-button @click="resetFilters">重置</el-button>
      </div>
      <div class="transaction-table-header">
        <div><h2>变动明细</h2><span>共 {{ filtered.length }} 条 · 最新记录优先</span></div>
        <el-button :icon="Download" :disabled="!filtered.length || loading || !!error" @click="exportCsv">导出当前范围 CSV</el-button>
      </div>
      <el-table :data="visibleRows" stripe style="width: 100%" @row-dblclick="showDetails">
        <el-table-column prop="id" label="流水 ID" width="100" />
        <el-table-column label="记录时间" min-width="175"><template #default="{ row }">{{ timeText(row.created_at) }}</template></el-table-column>
        <el-table-column label="仓库" min-width="120"><template #default="{ row }">{{ warehouseName(row.warehouse_id) }}</template></el-table-column>
        <el-table-column label="产品" min-width="200"><template #default="{ row }"><div>{{ product(row.product_id)?.name ?? `产品 ID ${row.product_id}` }}</div><small>{{ product(row.product_id)?.code }}</small></template></el-table-column>
        <el-table-column label="变动类型" min-width="120"><template #default="{ row }"><el-tag :type="row.transaction_type === 'production_receipt' ? 'success' : 'primary'" effect="light">{{ typeNames[row.transaction_type] ?? row.transaction_type }}</el-tag></template></el-table-column>
        <el-table-column label="变动数量" min-width="130" align="right"><template #default="{ row }"><b>{{ numberText(row.quantity) }}</b> {{ product(row.product_id)?.unit }}</template></el-table-column>
        <el-table-column label="操作" width="110" fixed="right"><template #default="{ row }"><el-button link type="primary" @click="showDetails(row)">查看来源</el-button></template></el-table-column>
        <template #empty><el-empty :description="error ? '暂时无法获取数据' : '暂无符合条件的库存流水'" /></template>
      </el-table>
      <div class="transaction-footer"><span>此处为库存变动流水；期初余额和库存预留不等于入库流水，不跨单位合计数量。</span><el-pagination v-model:current-page="page" :page-size="15" :total="filtered.length" layout="prev, pager, next" hide-on-single-page /></div>
    </el-card>
    <el-drawer v-model="detailOpen" title="库存变动来源" size="min(520px, 100%)">
      <template v-if="selected">
        <el-descriptions :column="1" border>
          <el-descriptions-item label="流水 ID">{{ selected.id }}</el-descriptions-item>
          <el-descriptions-item label="记录时间">{{ timeText(selected.created_at) }}</el-descriptions-item>
          <el-descriptions-item label="仓库">{{ warehouseName(selected.warehouse_id) }}</el-descriptions-item>
          <el-descriptions-item label="产品">{{ product(selected.product_id)?.name ?? selected.product_id }}</el-descriptions-item>
          <el-descriptions-item label="产品编码">{{ product(selected.product_id)?.code ?? '未找到' }}</el-descriptions-item>
          <el-descriptions-item label="变动类型">{{ typeNames[selected.transaction_type] ?? selected.transaction_type }}</el-descriptions-item>
          <el-descriptions-item label="变动数量">{{ numberText(selected.quantity) }} {{ product(selected.product_id)?.unit }}</el-descriptions-item>
          <el-descriptions-item label="来源类型">{{ sourceNames[selected.reference_type] ?? selected.reference_type }}</el-descriptions-item>
          <el-descriptions-item label="来源记录 ID">{{ selected.reference_id }}</el-descriptions-item>
        </el-descriptions>
        <el-alert class="source-note" title="来源记录 ID 是数据库关联标识，不是业务单号。" type="info" :closable="false" />
      </template>
    </el-drawer>
  </div>
</template>

<style scoped>
.transaction-header,.transaction-table-header,.transaction-footer{display:flex;justify-content:space-between;align-items:center;gap:16px}
.transaction-header{margin-bottom:20px}.transaction-header h1{margin:0;font-size:28px;color:#172033}.transaction-header p{margin:7px 0 0;color:#687386;font-size:14px}
.transaction-summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin:20px 0}
.transaction-summary .el-card{border-radius:12px;border-top:3px solid #327be4}.transaction-summary .teal{border-top-color:#24a395}
.transaction-summary span,.transaction-summary small{display:block;color:#687386}.transaction-summary strong{display:block;font-size:30px;color:#172033;margin:12px 0}.transaction-summary small{font-size:12px}
.transaction-panel{border-radius:12px}.transaction-filters{display:flex;flex-wrap:wrap;align-items:center;gap:12px;padding-bottom:18px;border-bottom:1px solid #edf0f5}
.transaction-filters .el-input{width:230px}.transaction-filters .el-select{width:160px}.transaction-filters :deep(.el-date-editor){max-width:300px}
.transaction-table-header{padding:18px 0}.transaction-table-header>div{display:flex;align-items:center;gap:12px}.transaction-table-header h2{margin:0;font-size:18px;color:#172033}
.transaction-table-header span,.transaction-footer{font-size:12px;color:#687386}.transaction-footer{margin-top:18px}.transaction-panel small{color:#687386}
.transaction-panel :deep(th.el-table__cell){background:#f5f7fb;color:#5c687a;height:46px}.transaction-panel :deep(td.el-table__cell){height:60px;color:#354052}.source-note{margin-top:20px}
@media(max-width:760px){.transaction-summary{grid-template-columns:1fr}.transaction-filters>*{width:100%!important}.transaction-table-header,.transaction-footer{align-items:flex-start;flex-direction:column}}
</style>
