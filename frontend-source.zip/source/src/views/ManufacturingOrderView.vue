<script setup lang="ts">
import {
  computed,
  onMounted,
  ref,
} from 'vue'

import {
  CircleCheck,
  Goods,
  Refresh,
  Tickets,
  VideoPlay,
} from '@element-plus/icons-vue'

import {
  ElMessage,
  ElMessageBox,
} from 'element-plus'

import api from '../services/api'

interface ManufacturingOrder {
  id: number
  order_no: string
  product_id: number
  planned_quantity: number | string
  source_sales_order_id: number | null
  source_sales_order_item_id: number | null
  status: string
  created_at: string
}

interface Product {
  id: number
  code: string
  name: string
  unit: string
  active: boolean
}

interface SalesOrder {
  id: number
  order_no: string
}

interface Warehouse {
  id: number
  code: string
  name: string
  active: boolean
}

interface ManufacturingReceiptResult {
  manufacturing_order_id: number
  warehouse_id: number
  product_id: number
  received_quantity: number | string
  auto_reserved_quantity: number | string
  on_hand_quantity: number | string
  reserved_quantity: number | string
  available_quantity: number | string
  manufacturing_order_status: string
}

interface MaterialRequirementLine {
  component_product_id: number
  unit_quantity: number | string
  required_quantity: number | string
  on_hand_quantity: number | string
  reserved_quantity: number | string
  available_quantity: number | string
  shortage_quantity: number | string
}

interface MaterialRequirement {
  manufacturing_order_id: number
  manufacturing_order_no: string
  product_id: number
  planned_quantity: number | string
  bom_id: number
  bom_name: string
  warehouse_id: number
  lines: MaterialRequirementLine[]
}

type TagType =
  | 'success'
  | 'warning'
  | 'info'
  | 'primary'
  | 'danger'

const manufacturingOrders =
  ref<ManufacturingOrder[]>([])

const products = ref<Product[]>([])
const salesOrders = ref<SalesOrder[]>([])
const warehouses = ref<Warehouse[]>([])

const loading = ref(false)
const saving = ref(false)

/* =========================
   生产入库
   ========================= */

const receiptDialogVisible =
  ref(false)

const receivingOrder =
  ref<ManufacturingOrder | null>(null)

const receiptWarehouseId =
  ref<number | null>(null)

const receiptResult =
  ref<ManufacturingReceiptResult | null>(
    null
  )

const receiptResultDialogVisible =
  ref(false)

/* =========================
   物料需求
   ========================= */

const materialDrawerVisible =
  ref(false)

const materialLoading =
  ref(false)

const materialError =
  ref('')

const materialOrder =
  ref<ManufacturingOrder | null>(
    null
  )

const materialWarehouseId =
  ref<number | null>(null)

const materialRequirement =
  ref<MaterialRequirement | null>(
    null
  )

/* =========================
   基础数据
   ========================= */

const activeWarehouses = computed(
  () =>
    warehouses.value.filter(
      warehouse => warehouse.active
    )
)

async function loadData() {
  loading.value = true

  try {
    const [
      manufacturingOrderResponse,
      productResponse,
      salesOrderResponse,
      warehouseResponse,
    ] = await Promise.all([
      api.get<ManufacturingOrder[]>(
        '/manufacturing-orders'
      ),

      api.get<Product[]>(
        '/products'
      ),

      api.get<SalesOrder[]>(
        '/sales-orders'
      ),

      api.get<Warehouse[]>(
        '/warehouses'
      ),
    ])

    manufacturingOrders.value =
      manufacturingOrderResponse.data

    products.value =
      productResponse.data

    salesOrders.value =
      salesOrderResponse.data

    warehouses.value =
      warehouseResponse.data
  } catch (error) {
    console.error(error)

    ElMessage.error(
      '生产订单数据加载失败'
    )
  } finally {
    loading.value = false
  }
}

/* =========================
   汇总数据
   ========================= */

const totalOrders = computed(
  () =>
    manufacturingOrders.value.length
)

const plannedOrders = computed(
  () =>
    manufacturingOrders.value.filter(
      order =>
        order.status === 'planned'
    ).length
)

const activeOrders = computed(
  () =>
    manufacturingOrders.value.filter(
      order =>
        order.status === 'released' ||
        order.status === 'in_progress'
    ).length
)

const completedWaitingReceipt =
  computed(
    () =>
      manufacturingOrders.value.filter(
        order =>
          order.status === 'completed'
      ).length
  )

const receivedOrders = computed(
  () =>
    manufacturingOrders.value.filter(
      order =>
        order.status === 'received'
    ).length
)

/* =========================
   下达生产
   ========================= */

async function releaseManufacturingOrder(
  order: ManufacturingOrder
) {
  try {
    await ElMessageBox.confirm(
      `确定下达生产订单“${order.order_no}”吗？下达后系统会生成生产工序。`,
      '下达生产',
      {
        confirmButtonText: '确定下达',
        cancelButtonText: '取消',
        type: 'warning',
      }
    )
  } catch {
    return
  }

  saving.value = true

  try {
    await api.patch(
      `/manufacturing-orders/${order.id}/release`
    )

    ElMessage.success(
      `生产订单 ${order.order_no} 已下达`
    )

    await loadData()
  } catch (error: any) {
    console.error(error)

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `下达失败：${detail}`
        : '生产订单下达失败'
    )
  } finally {
    saving.value = false
  }
}

/* =========================
   生产入库
   ========================= */

function openReceiptDialog(
  order: ManufacturingOrder
) {
  receivingOrder.value = order
  receiptResult.value = null

  const firstWarehouse =
    activeWarehouses.value[0]

  receiptWarehouseId.value =
    firstWarehouse?.id ?? null

  receiptDialogVisible.value = true
}

async function receiveManufacturingOrder() {
  if (
    receivingOrder.value === null
  ) {
    return
  }

  if (
    receiptWarehouseId.value === null
  ) {
    ElMessage.warning(
      '请选择入库仓库'
    )

    return
  }

  try {
    await ElMessageBox.confirm(
      `确定将生产订单“${receivingOrder.value.order_no}”的 ${formatQuantity(receivingOrder.value.planned_quantity)} 入库吗？`,
      '确认生产入库',
      {
        confirmButtonText: '确认入库',
        cancelButtonText: '取消',
        type: 'warning',
      }
    )
  } catch {
    return
  }

  saving.value = true

  try {
    const response =
      await api.post<ManufacturingReceiptResult>(
        `/manufacturing-orders/${receivingOrder.value.id}/receive`,
        {
          warehouse_id:
            receiptWarehouseId.value,
        }
      )

    receiptResult.value =
      response.data

    receiptDialogVisible.value =
      false

    receiptResultDialogVisible.value =
      true

    ElMessage.success(
      '生产入库成功'
    )

    await loadData()
  } catch (error: any) {
    console.error(error)

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `入库失败：${detail}`
        : '生产入库失败'
    )
  } finally {
    saving.value = false
  }
}

/* =========================
   查看物料需求
   ========================= */

async function openMaterialRequirement(
  order: ManufacturingOrder
) {
  materialOrder.value = order
  materialRequirement.value = null
  materialError.value = ''

  const firstWarehouse =
    activeWarehouses.value[0]

  materialWarehouseId.value =
    firstWarehouse?.id ?? null

  materialDrawerVisible.value =
    true

  await loadMaterialRequirement()
}


async function loadMaterialRequirement() {
  if (
    materialOrder.value === null ||
    materialWarehouseId.value === null
  ) {
    return
  }

  materialLoading.value = true
  materialError.value = ''

  try {
    const response =
      await api.get<MaterialRequirement>(
        `/manufacturing-orders/${materialOrder.value.id}/material-requirements`,
        {
          params: {
            warehouse_id:
              materialWarehouseId.value,
          },
        }
      )

    materialRequirement.value =
      response.data
  } catch (error: any) {
    console.error(error)

    materialRequirement.value =
      null

    const detail =
      error.response?.data?.detail

    materialError.value =
      detail ??
      '物料需求加载失败'
  } finally {
    materialLoading.value = false
  }
}


async function handleMaterialWarehouseChange() {
  await loadMaterialRequirement()
}


function closeMaterialDrawer() {
  materialDrawerVisible.value =
    false

  materialOrder.value = null
  materialRequirement.value = null
  materialError.value = ''
}

/* =========================
   显示辅助
   ========================= */

function getProductName(
  productId: number
) {
  const product =
    products.value.find(
      item =>
        item.id === productId
    )

  if (!product) {
    return `产品 #${productId}`
  }

  return (
    `${product.code} / ` +
    `${product.name}`
  )
}

function getProductUnit(
  productId: number
) {
  const product =
    products.value.find(
      item =>
        item.id === productId
    )

  return product?.unit ?? ''
}

function getSalesOrderName(
  salesOrderId: number | null
) {
  if (
    salesOrderId === null
  ) {
    return '-'
  }

  const order =
    salesOrders.value.find(
      item =>
        item.id === salesOrderId
    )

  return (
    order?.order_no ??
    `销售订单 #${salesOrderId}`
  )
}

function getWarehouseName(
  warehouseId: number
) {
  const warehouse =
    warehouses.value.find(
      item =>
        item.id === warehouseId
    )

  if (!warehouse) {
    return `仓库 #${warehouseId}`
  }

  return (
    `${warehouse.code} / ` +
    `${warehouse.name}`
  )
}

function getStatusText(
  status: string
) {
  const statusMap:
    Record<string, string> = {
      planned: '计划中',
      released: '已下达',
      in_progress: '生产中',
      completed: '已完成',
      received: '已入库',
    }

  return statusMap[status] ?? status
}

function getStatusType(
  status: string
): TagType {
  const statusMap:
    Record<string, TagType> = {
      planned: 'info',
      released: 'primary',
      in_progress: 'warning',
      completed: 'success',
      received: 'success',
    }

  return statusMap[status] ?? 'info'
}

function formatQuantity(
  value: number | string
) {
  return Number(value).toFixed(3)
}

function formatDate(
  dateText: string
) {
  return new Date(
    dateText
  ).toLocaleString()
}

onMounted(() => {
  loadData()
})
</script>

<template>
  <div class="manufacturing-page">
    <!-- 页面标题 -->
    <div class="business-page-header">
      <div>
        <h1>生产订单</h1>

        <p>
          管理 ERP 生产计划、生产下达以及成品入库
        </p>
      </div>

      <div class="business-page-actions">
        <el-button
          :icon="Refresh"
          :loading="loading"
          @click="loadData"
        >
          刷新
        </el-button>
      </div>
    </div>

    <!-- 状态概览 -->
    <div class="production-summary-grid">
      <el-card
        shadow="never"
        class="production-summary-card"
      >
        <div class="summary-card-content">
          <div
            class="summary-icon
                   summary-icon-blue"
          >
            <el-icon>
              <Tickets />
            </el-icon>
          </div>

          <div>
            <div class="summary-label">
              生产订单
            </div>

            <div class="summary-value">
              {{ totalOrders }}
            </div>

            <div class="summary-note">
              全部生产订单
            </div>
          </div>
        </div>
      </el-card>

      <el-card
        shadow="never"
        class="production-summary-card"
      >
        <div class="summary-card-content">
          <div
            class="summary-icon
                   summary-icon-gray"
          >
            <el-icon>
              <Tickets />
            </el-icon>
          </div>

          <div>
            <div class="summary-label">
              待下达
            </div>

            <div class="summary-value">
              {{ plannedOrders }}
            </div>

            <div class="summary-note">
              状态为计划中
            </div>
          </div>
        </div>
      </el-card>

      <el-card
        shadow="never"
        class="production-summary-card"
      >
        <div class="summary-card-content">
          <div
            class="summary-icon
                   summary-icon-orange"
          >
            <el-icon>
              <Tickets />
            </el-icon>
          </div>

          <div>
            <div class="summary-label">
              正在执行
            </div>

            <div class="summary-value">
              {{ activeOrders }}
            </div>

            <div class="summary-note">
              已下达 / 生产中
            </div>
          </div>
        </div>
      </el-card>

      <el-card
        shadow="never"
        class="production-summary-card"
      >
        <div class="summary-card-content">
          <div
            class="summary-icon
                   summary-icon-purple"
          >
            <el-icon>
              <CircleCheck />
            </el-icon>
          </div>

          <div>
            <div class="summary-label">
              待入库
            </div>

            <div class="summary-value">
              {{
                completedWaitingReceipt
              }}
            </div>

            <div class="summary-note">
              已生产完成
            </div>
          </div>
        </div>
      </el-card>

      <el-card
        shadow="never"
        class="production-summary-card"
      >
        <div class="summary-card-content">
          <div
            class="summary-icon
                   summary-icon-green"
          >
            <el-icon>
              <Goods />
            </el-icon>
          </div>

          <div>
            <div class="summary-label">
              已入库
            </div>

            <div class="summary-value">
              {{ receivedOrders }}
            </div>

            <div class="summary-note">
              已完成生产入库
            </div>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 主表格 -->
    <el-card
      shadow="never"
      class="business-card"
    >
      <el-table
        v-loading="loading"
        :data="manufacturingOrders"
        stripe
        style="width: 100%"
      >
        <el-table-column
          prop="id"
          label="ID"
          width="70"
        />

        <el-table-column
          prop="order_no"
          label="生产订单号"
          min-width="180"
        >
          <template #default="{ row }">
            <span class="code-text">
              {{ row.order_no }}
            </span>
          </template>
        </el-table-column>

        <el-table-column
          label="产品"
          min-width="220"
        >
          <template #default="{ row }">
            <div class="product-cell">
              <span>
                {{
                  getProductName(
                    row.product_id
                  )
                }}
              </span>

              <small>
                单位：
                {{
                  getProductUnit(
                    row.product_id
                  )
                }}
              </small>
            </div>
          </template>
        </el-table-column>

        <el-table-column
          label="计划数量"
          width="130"
          align="right"
        >
          <template #default="{ row }">
            <span class="quantity-text">
              {{
                formatQuantity(
                  row.planned_quantity
                )
              }}
            </span>
          </template>
        </el-table-column>

        <el-table-column
          label="来源销售订单"
          min-width="170"
        >
          <template #default="{ row }">
            {{
              getSalesOrderName(
                row.source_sales_order_id
              )
            }}
          </template>
        </el-table-column>

        <el-table-column
          label="状态"
          width="120"
        >
          <template #default="{ row }">
            <el-tag
              :type="
                getStatusType(
                  row.status
                )
              "
              effect="light"
              round
            >
              {{
                getStatusText(
                  row.status
                )
              }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column
          label="创建时间"
          min-width="190"
        >
          <template #default="{ row }">
            {{
              formatDate(
                row.created_at
              )
            }}
          </template>
        </el-table-column>

        <el-table-column
          label="操作"
          width="280"
          fixed="right"
        >
          <template #default="{ row }">
            <div class="production-actions">
              <el-button
                size="small"
                plain
                @click="
                  openMaterialRequirement(
                    row
                  )
                "
              >
                物料需求
              </el-button>

              <el-button
                v-if="
                  row.status === 'planned'
                "
                type="primary"
                size="small"
                :icon="VideoPlay"
                :disabled="saving"
                @click="
                  releaseManufacturingOrder(
                    row
                  )
                "
              >
                下达生产
              </el-button>

              <el-button
                v-else-if="
                  row.status ===
                  'completed'
                "
                type="success"
                size="small"
                :icon="Goods"
                :disabled="saving"
                @click="
                  openReceiptDialog(
                    row
                  )
                "
              >
                生产入库
              </el-button>

              <el-tag
                v-else-if="
                  row.status === 'received'
                "
                type="success"
                effect="plain"
                size="small"
              >
                已完成
              </el-tag>

              <span
                v-else
                class="no-action-text"
              >
                -
              </span>
            </div>
          </template>
        </el-table-column>

        <template #empty>
          <el-empty
            description="暂无生产订单"
          />
        </template>
      </el-table>
    </el-card>

    <!-- =======================
         物料需求 Drawer
         ======================= -->

    <el-drawer
      v-model="materialDrawerVisible"
      title="生产物料需求"
      size="820px"
      destroy-on-close
      @closed="closeMaterialDrawer"
    >
      <template v-if="materialOrder">
        <div class="material-header">
          <div>
            <span>
              生产订单
            </span>

            <h2>
              {{
                materialOrder.order_no
              }}
            </h2>
          </div>

          <el-tag
            :type="
              getStatusType(
                materialOrder.status
              )
            "
            effect="light"
            round
          >
            {{
              getStatusText(
                materialOrder.status
              )
            }}
          </el-tag>
        </div>

        <el-descriptions
          :column="2"
          border
          class="material-order-description"
        >
          <el-descriptions-item
            label="产品"
          >
            {{
              getProductName(
                materialOrder.product_id
              )
            }}
          </el-descriptions-item>

          <el-descriptions-item
            label="计划数量"
          >
            {{
              formatQuantity(
                materialOrder
                  .planned_quantity
              )
            }}
          </el-descriptions-item>
        </el-descriptions>

        <div class="material-toolbar">
          <div>
            <strong>
              库存仓库
            </strong>

            <span>
              物料库存按所选仓库计算
            </span>
          </div>

          <el-select
            v-model="materialWarehouseId"
            style="width: 240px"
            @change="
              handleMaterialWarehouseChange
            "
          >
            <el-option
              v-for="
                warehouse
                in activeWarehouses
              "
              :key="warehouse.id"
              :label="
                `${warehouse.code} / ${warehouse.name}`
              "
              :value="warehouse.id"
            />
          </el-select>
        </div>

        <el-alert
          v-if="materialError"
          :title="materialError"
          type="warning"
          show-icon
          :closable="false"
          class="material-error"
        />

        <div
          v-loading="materialLoading"
          class="material-content"
        >
          <template
            v-if="materialRequirement"
          >
            <div class="bom-info">
              <div>
                <span>
                  使用 BOM
                </span>

                <strong>
                  {{
                    materialRequirement
                      .bom_name
                  }}
                </strong>
              </div>

              <el-tag
                type="primary"
                effect="light"
              >
                {{
                  materialRequirement
                    .lines.length
                }}
                项物料
              </el-tag>
            </div>

            <el-table
              :data="
                materialRequirement.lines
              "
              stripe
              border
              style="width: 100%"
            >
              <el-table-column
                label="物料"
                min-width="200"
              >
                <template #default="{ row }">
                  <div class="material-product">
                    <strong>
                      {{
                        getProductName(
                          row.component_product_id
                        )
                      }}
                    </strong>

                    <span>
                      单位：
                      {{
                        getProductUnit(
                          row.component_product_id
                        )
                      }}
                    </span>
                  </div>
                </template>
              </el-table-column>

              <el-table-column
                label="单位用量"
                width="105"
                align="right"
              >
                <template #default="{ row }">
                  {{
                    formatQuantity(
                      row.unit_quantity
                    )
                  }}
                </template>
              </el-table-column>

              <el-table-column
                label="总需求"
                width="105"
                align="right"
              >
                <template #default="{ row }">
                  <strong>
                    {{
                      formatQuantity(
                        row.required_quantity
                      )
                    }}
                  </strong>
                </template>
              </el-table-column>

              <el-table-column
                label="现有"
                width="95"
                align="right"
              >
                <template #default="{ row }">
                  {{
                    formatQuantity(
                      row.on_hand_quantity
                    )
                  }}
                </template>
              </el-table-column>

              <el-table-column
                label="预留"
                width="95"
                align="right"
              >
                <template #default="{ row }">
                  {{
                    formatQuantity(
                      row.reserved_quantity
                    )
                  }}
                </template>
              </el-table-column>

              <el-table-column
                label="可用"
                width="95"
                align="right"
              >
                <template #default="{ row }">
                  {{
                    formatQuantity(
                      row.available_quantity
                    )
                  }}
                </template>
              </el-table-column>

              <el-table-column
                label="缺料"
                width="105"
                align="right"
              >
                <template #default="{ row }">
                  <el-tag
                    :type="
                      Number(
                        row.shortage_quantity
                      ) > 0
                        ? 'danger'
                        : 'success'
                    "
                    effect="light"
                  >
                    {{
                      formatQuantity(
                        row.shortage_quantity
                      )
                    }}
                  </el-tag>
                </template>
              </el-table-column>
            </el-table>
          </template>
        </div>
      </template>
    </el-drawer>

    <!-- =======================
         生产入库 Dialog
         ======================= -->

    <el-dialog
      v-model="receiptDialogVisible"
      title="生产入库"
      width="540px"
      destroy-on-close
    >
      <template
        v-if="receivingOrder"
      >
        <el-alert
          title="生产入库后将增加现有库存，并自动补充分配给来源销售订单的库存预留。"
          type="success"
          show-icon
          :closable="false"
          class="receipt-alert"
        />

        <el-descriptions
          :column="1"
          border
          class="receipt-description"
        >
          <el-descriptions-item
            label="生产订单"
          >
            <span class="code-text">
              {{
                receivingOrder.order_no
              }}
            </span>
          </el-descriptions-item>

          <el-descriptions-item
            label="产品"
          >
            {{
              getProductName(
                receivingOrder.product_id
              )
            }}
          </el-descriptions-item>

          <el-descriptions-item
            label="入库数量"
          >
            <strong>
              {{
                formatQuantity(
                  receivingOrder.planned_quantity
                )
              }}
            </strong>

            {{
              getProductUnit(
                receivingOrder.product_id
              )
            }}
          </el-descriptions-item>

          <el-descriptions-item
            label="来源销售订单"
          >
            {{
              getSalesOrderName(
                receivingOrder.source_sales_order_id
              )
            }}
          </el-descriptions-item>
        </el-descriptions>

        <el-form
          label-position="top"
          class="receipt-form"
        >
          <el-form-item
            label="入库仓库"
            required
          >
            <el-select
              v-model="
                receiptWarehouseId
              "
              placeholder="请选择入库仓库"
              style="width: 100%"
            >
              <el-option
                v-for="
                  warehouse
                  in activeWarehouses
                "
                :key="warehouse.id"
                :label="
                  `${warehouse.code} / ${warehouse.name}`
                "
                :value="warehouse.id"
              />
            </el-select>
          </el-form-item>
        </el-form>
      </template>

      <template #footer>
        <div class="dialog-footer">
          <el-button
            :disabled="saving"
            @click="
              receiptDialogVisible =
                false
            "
          >
            取消
          </el-button>

          <el-button
            type="primary"
            :loading="saving"
            @click="
              receiveManufacturingOrder
            "
          >
            确认入库
          </el-button>
        </div>
      </template>
    </el-dialog>

    <!-- =======================
         入库结果 Dialog
         ======================= -->

    <el-dialog
      v-model="
        receiptResultDialogVisible
      "
      title="生产入库结果"
      width="620px"
    >
      <template v-if="receiptResult">
        <el-result
          icon="success"
          title="生产入库成功"
          sub-title="库存与销售订单预留已经同步更新"
        />

        <el-descriptions
          :column="2"
          border
        >
          <el-descriptions-item
            label="生产订单"
          >
            {{
              receivingOrder?.order_no
                ?? `#${receiptResult.manufacturing_order_id}`
            }}
          </el-descriptions-item>

          <el-descriptions-item
            label="入库仓库"
          >
            {{
              getWarehouseName(
                receiptResult.warehouse_id
              )
            }}
          </el-descriptions-item>

          <el-descriptions-item
            label="本次入库"
          >
            <strong>
              {{
                formatQuantity(
                  receiptResult.received_quantity
                )
              }}
            </strong>
          </el-descriptions-item>

          <el-descriptions-item
            label="自动预留"
          >
            <strong class="reserved-text">
              {{
                formatQuantity(
                  receiptResult.auto_reserved_quantity
                )
              }}
            </strong>
          </el-descriptions-item>

          <el-descriptions-item
            label="入库后现有库存"
          >
            {{
              formatQuantity(
                receiptResult.on_hand_quantity
              )
            }}
          </el-descriptions-item>

          <el-descriptions-item
            label="入库后预留库存"
          >
            {{
              formatQuantity(
                receiptResult.reserved_quantity
              )
            }}
          </el-descriptions-item>

          <el-descriptions-item
            label="入库后可用库存"
            :span="2"
          >
            <el-tag
              :type="
                Number(
                  receiptResult.available_quantity
                ) > 0
                  ? 'success'
                  : 'warning'
              "
              effect="light"
            >
              {{
                formatQuantity(
                  receiptResult.available_quantity
                )
              }}
            </el-tag>
          </el-descriptions-item>
        </el-descriptions>
      </template>

      <template #footer>
        <el-button
          type="primary"
          @click="
            receiptResultDialogVisible =
              false
          "
        >
          知道了
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.manufacturing-page {
  width: 100%;
}

.business-page-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  gap: 20px;
  margin-bottom: 22px;
}

.business-page-header h1 {
  margin: 0;

  color: #172033;
  font-size: 28px;
  font-weight: 700;
}

.business-page-header p {
  margin: 7px 0 0;

  color: #8a94a5;
  font-size: 14px;
}

.business-page-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

/* 汇总 */

.production-summary-grid {
  display: grid;

  grid-template-columns:
    repeat(
      5,
      minmax(0, 1fr)
    );

  gap: 14px;
  margin-bottom: 22px;
}

.production-summary-card {
  border-radius: 12px;
  border: 1px solid #e7ebf0;
}

.production-summary-card :deep(
  .el-card__body
) {
  padding: 18px;
}

.summary-card-content {
  display: flex;
  align-items: center;
  gap: 14px;
}

.summary-icon {
  width: 44px;
  height: 44px;

  flex-shrink: 0;

  display: flex;
  align-items: center;
  justify-content: center;

  border-radius: 11px;

  font-size: 21px;
}

.summary-icon-blue {
  color: #2c7be5;
  background: #edf4ff;
}

.summary-icon-gray {
  color: #6f7b8e;
  background: #f0f2f5;
}

.summary-icon-orange {
  color: #d79024;
  background: #fff5e5;
}

.summary-icon-purple {
  color: #7763c5;
  background: #f1edff;
}

.summary-icon-green {
  color: #3b9d64;
  background: #ebf8f0;
}

.summary-label {
  color: #7d8796;
  font-size: 12px;
}

.summary-value {
  margin-top: 3px;

  color: #172033;
  font-size: 23px;
  font-weight: 700;
}

.summary-note {
  margin-top: 3px;

  color: #9aa3b1;
  font-size: 10px;
}

/* 表格 */

.business-card {
  border-radius: 12px;
  border: 1px solid #e7ebf0;
}

.business-card :deep(
  .el-card__body
) {
  padding: 0;
}

.business-card :deep(
  .el-table
) {
  --el-table-border-color:
    #edf0f4;

  --el-table-header-bg-color:
    #f8fafc;

  --el-table-row-hover-bg-color:
    #f6f9fe;
}

.business-card :deep(
  th.el-table__cell
) {
  height: 50px;

  color: #687386;
  font-weight: 600;
}

.business-card :deep(
  td.el-table__cell
) {
  height: 62px;

  color: #354052;
}

.code-text {
  color: #2c7be5;
  font-weight: 600;
}

.product-cell {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.product-cell small {
  color: #98a1af;
  font-size: 11px;
}

.quantity-text {
  color: #172033;
  font-weight: 700;
}

.reserved-text {
  color: #d79024;
  font-weight: 700;
}

.production-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.production-actions
:deep(.el-button) {
  min-width: 96px;
  border-radius: 7px;
  font-weight: 500;
}

.no-action-text {
  color: #a5adba;
}

.receipt-alert {
  margin-bottom: 18px;
}

.receipt-description {
  margin-bottom: 20px;
}

.receipt-form {
  margin-top: 4px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

/* 物料需求 */

.material-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 20px;
  padding-bottom: 18px;
  border-bottom: 1px solid #edf0f4;
}

.material-header span {
  color: #929baa;
  font-size: 11px;
}

.material-header h2 {
  margin: 5px 0 0;
  color: #172033;
  font-size: 23px;
}

.material-order-description {
  margin-top: 20px;
}

.material-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  margin-top: 24px;
  margin-bottom: 18px;
}

.material-toolbar > div {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.material-toolbar strong {
  color: #354052;
  font-size: 14px;
}

.material-toolbar span {
  color: #929baa;
  font-size: 11px;
}

.material-error {
  margin-bottom: 18px;
}

.material-content {
  min-height: 160px;
}

.bom-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  padding: 14px 16px;
  margin-bottom: 16px;
  border-radius: 9px;
  background: #f7f9fc;
}

.bom-info > div {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.bom-info span {
  color: #929baa;
  font-size: 11px;
}

.bom-info strong {
  color: #2c7be5;
  font-size: 14px;
}

.material-product {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.material-product strong {
  color: #354052;
}

.material-product span {
  color: #929baa;
  font-size: 11px;
}

@media (max-width: 1200px) {
  .production-summary-grid {
    grid-template-columns:
      repeat(
        3,
        minmax(0, 1fr)
      );
  }
}

@media (max-width: 800px) {
  .business-page-header {
    flex-direction: column;
  }

  .production-summary-grid {
    grid-template-columns:
      repeat(
        2,
        minmax(0, 1fr)
      );
  }
}
</style>
