<script setup lang="ts">
import { onMounted, ref } from 'vue'

import {
  Edit,
  Plus,
  Refresh,
  SwitchButton,
} from '@element-plus/icons-vue'

import {
  ElMessage,
  ElMessageBox,
} from 'element-plus'

import api from '../services/api'

interface Customer {
  id: number
  code: string
  name: string
  contact_name: string | null
  phone: string | null
  active: boolean
}

const customers = ref<Customer[]>([])

const loading = ref(false)
const saving = ref(false)

const dialogVisible = ref(false)

const dialogMode = ref<'create' | 'edit'>(
  'create'
)

const editingCustomerId =
  ref<number | null>(null)

const customerForm = ref({
  code: '',
  name: '',
  contact_name: '',
  phone: '',
})

async function loadCustomers() {
  loading.value = true

  try {
    const response =
      await api.get<Customer[]>('/customers')

    customers.value = response.data
  } catch (error) {
    console.error(error)

    ElMessage.error(
      '客户数据加载失败'
    )
  } finally {
    loading.value = false
  }
}

function openCreateDialog() {
  dialogMode.value = 'create'
  editingCustomerId.value = null

  customerForm.value = {
    code: '',
    name: '',
    contact_name: '',
    phone: '',
  }

  dialogVisible.value = true
}

function openEditDialog(
  customer: Customer
) {
  dialogMode.value = 'edit'

  editingCustomerId.value =
    customer.id

  customerForm.value = {
    code: customer.code,
    name: customer.name,
    contact_name:
      customer.contact_name ?? '',
    phone:
      customer.phone ?? '',
  }

  dialogVisible.value = true
}

async function saveCustomer() {
  if (
    !customerForm.value.code.trim() ||
    !customerForm.value.name.trim()
  ) {
    ElMessage.warning(
      '客户编码和客户名称不能为空'
    )

    return
  }

  saving.value = true

  try {
    const payload = {
      code:
        customerForm.value.code.trim(),

      name:
        customerForm.value.name.trim(),

      contact_name:
        customerForm.value.contact_name.trim()
          || null,

      phone:
        customerForm.value.phone.trim()
          || null,
    }

    if (
      dialogMode.value === 'create'
    ) {
      await api.post(
        '/customers',
        payload
      )

      ElMessage.success(
        '客户新增成功'
      )
    } else {
      if (
        editingCustomerId.value === null
      ) {
        return
      }

      await api.put(
        `/customers/${editingCustomerId.value}`,
        payload
      )

      ElMessage.success(
        '客户修改成功'
      )
    }

    dialogVisible.value = false

    await loadCustomers()
  } catch (error: any) {
    console.error(error)

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `保存失败：${detail}`
        : '客户保存失败'
    )
  } finally {
    saving.value = false
  }
}

async function toggleCustomerStatus(
  customer: Customer
) {
  const actionText =
    customer.active
      ? '停用'
      : '启用'

  try {
    await ElMessageBox.confirm(
      `确定要${actionText}客户“${customer.code} / ${customer.name}”吗？`,
      `${actionText}客户`,
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',

        type:
          customer.active
            ? 'warning'
            : 'success',
      }
    )
  } catch {
    return
  }

  saving.value = true

  try {
    const endpoint =
      customer.active
        ? `/customers/${customer.id}/deactivate`
        : `/customers/${customer.id}/activate`

    await api.patch(endpoint)

    ElMessage.success(
      `${actionText}成功`
    )

    await loadCustomers()
  } catch (error: any) {
    console.error(error)

    const detail =
      error.response?.data?.detail

    ElMessage.error(
      detail
        ? `${actionText}失败：${detail}`
        : `${actionText}客户失败`
    )
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  loadCustomers()
})
</script>

<template>
  <div class="customer-page">
    <div class="business-page-header">
      <div>
        <h1>客户管理</h1>

        <p>
          维护 ERP 客户主数据、
          联系方式与客户状态
        </p>
      </div>

      <div class="business-page-actions">
        <el-button
          :icon="Refresh"
          :loading="loading"
          @click="loadCustomers"
        >
          刷新
        </el-button>

        <el-button
          type="primary"
          :icon="Plus"
          @click="openCreateDialog"
        >
          新增客户
        </el-button>
      </div>
    </div>

    <el-card
      shadow="never"
      class="business-card"
    >
      <el-table
        v-loading="loading"
        :data="customers"
        stripe
        style="width: 100%"
      >
        <el-table-column
          prop="id"
          label="ID"
          width="80"
        />

        <el-table-column
          prop="code"
          label="客户编码"
          min-width="170"
        >
          <template #default="{ row }">
            <span class="code-text">
              {{ row.code }}
            </span>
          </template>
        </el-table-column>

        <el-table-column
          prop="name"
          label="客户名称"
          min-width="200"
        />

        <el-table-column
          label="联系人"
          min-width="150"
        >
          <template #default="{ row }">
            {{
              row.contact_name || '-'
            }}
          </template>
        </el-table-column>

        <el-table-column
          label="联系电话"
          min-width="170"
        >
          <template #default="{ row }">
            {{
              row.phone || '-'
            }}
          </template>
        </el-table-column>

        <el-table-column
          label="状态"
          width="120"
        >
          <template #default="{ row }">
            <el-tag
              :type="
                row.active
                  ? 'success'
                  : 'info'
              "
              effect="light"
              round
            >
              {{
                row.active
                  ? '启用'
                  : '停用'
              }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column
          label="操作"
          width="210"
          fixed="right"
        >
          <template #default="{ row }">
            <el-button
              link
              type="primary"
              :icon="Edit"
              @click="
                openEditDialog(row)
              "
            >
              编辑
            </el-button>

            <el-button
              link
              :type="
                row.active
                  ? 'danger'
                  : 'success'
              "
              :icon="SwitchButton"
              :disabled="saving"
              @click="
                toggleCustomerStatus(row)
              "
            >
              {{
                row.active
                  ? '停用'
                  : '启用'
              }}
            </el-button>
          </template>
        </el-table-column>

        <template #empty>
          <el-empty
            description="暂无客户数据"
          />
        </template>
      </el-table>
    </el-card>

    <el-dialog
      v-model="dialogVisible"
      :title="
        dialogMode === 'create'
          ? '新增客户'
          : '编辑客户'
      "
      width="560px"
      destroy-on-close
    >
      <el-form
        label-position="top"
      >
        <el-form-item
          label="客户编码"
          required
        >
          <el-input
            v-model="
              customerForm.code
            "
            placeholder="例如 CUST-D"
            clearable
          />
        </el-form-item>

        <el-form-item
          label="客户名称"
          required
        >
          <el-input
            v-model="
              customerForm.name
            "
            placeholder="例如 客户D"
            clearable
          />
        </el-form-item>

        <el-form-item
          label="联系人"
        >
          <el-input
            v-model="
              customerForm.contact_name
            "
            placeholder="例如 张经理"
            clearable
          />
        </el-form-item>

        <el-form-item
          label="联系电话"
        >
          <el-input
            v-model="
              customerForm.phone
            "
            placeholder="例如 13800000000"
            clearable
          />
        </el-form-item>
      </el-form>

      <template #footer>
        <div class="dialog-footer">
          <el-button
            :disabled="saving"
            @click="
              dialogVisible = false
            "
          >
            取消
          </el-button>

          <el-button
            type="primary"
            :loading="saving"
            @click="saveCustomer"
          >
            {{
              dialogMode === 'create'
                ? '创建客户'
                : '保存修改'
            }}
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.customer-page {
  width: 100%;
}

.business-page-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  gap: 20px;
  margin-bottom: 22px;
}

.business-page-header h1 {
  margin: 0;

  color: #172033;

  font-size: 28px;
  font-weight: 700;
}

.business-page-header p {
  margin: 7px 0 0;

  color: #8a94a5;
  font-size: 14px;
}

.business-page-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.business-card {
  border-radius: 12px;
  border: 1px solid #e7ebf0;
}

.business-card :deep(
  .el-card__body
) {
  padding: 0;
}

.business-card :deep(
  .el-table
) {
  --el-table-border-color:
    #edf0f4;

  --el-table-header-bg-color:
    #f8fafc;

  --el-table-row-hover-bg-color:
    #f6f9fe;
}

.business-card :deep(
  th.el-table__cell
) {
  height: 50px;

  color: #687386;
  font-weight: 600;
}

.business-card :deep(
  td.el-table__cell
) {
  height: 58px;

  color: #354052;
}

.code-text {
  color: #2c7be5;
  font-weight: 600;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

@media (max-width: 700px) {
  .business-page-header {
    flex-direction: column;
  }
}
</style>