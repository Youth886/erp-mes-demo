<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'

import {
  Document,
  Goods,
  Tickets,
  CircleCheck,
  Refresh,
} from '@element-plus/icons-vue'

import api from '../services/api'

interface SalesOrder {
  id: number
  order_no: string
  status: string
  total_amount: number | string
  created_at: string
}

interface Inventory {
  id: number
  on_hand_quantity: number | string
  reserved_quantity: number | string
  available_quantity: number | string
}

interface ManufacturingOrder {
  id: number
  order_no: string
  planned_quantity: number | string
  status: string
  created_at: string
}

type TagType =
  | 'success'
  | 'warning'
  | 'info'
  | 'primary'
  | 'danger'

const salesOrders = ref<SalesOrder[]>([])
const inventory = ref<Inventory[]>([])
const manufacturingOrders =
  ref<ManufacturingOrder[]>([])

const loading = ref(false)
const errorMessage = ref('')

async function loadDashboard() {
  loading.value = true
  errorMessage.value = ''

  try {
    const [
      salesOrderResponse,
      inventoryResponse,
      manufacturingOrderResponse,
    ] = await Promise.all([
      api.get<SalesOrder[]>('/sales-orders'),
      api.get<Inventory[]>('/inventory'),
      api.get<ManufacturingOrder[]>(
        '/manufacturing-orders'
      ),
    ])

    salesOrders.value = salesOrderResponse.data
    inventory.value = inventoryResponse.data
    manufacturingOrders.value =
      manufacturingOrderResponse.data
  } catch (error) {
    console.error(error)
    errorMessage.value = '仪表盘数据加载失败'
  } finally {
    loading.value = false
  }
}

const totalSalesOrders = computed(
  () => salesOrders.value.length
)

const draftSalesOrders = computed(
  () =>
    salesOrders.value.filter(
      order => order.status === 'draft'
    ).length
)

const confirmedSalesOrders = computed(
  () =>
    salesOrders.value.filter(
      order => order.status === 'confirmed'
    ).length
)

const totalOnHand = computed(
  () =>
    inventory.value.reduce(
      (total, row) =>
        total + Number(row.on_hand_quantity),
      0
    )
)

const totalReserved = computed(
  () =>
    inventory.value.reduce(
      (total, row) =>
        total + Number(row.reserved_quantity),
      0
    )
)

const totalAvailable = computed(
  () =>
    inventory.value.reduce(
      (total, row) =>
        total + Number(row.available_quantity),
      0
    )
)

const activeManufacturingOrders = computed(
  () =>
    manufacturingOrders.value.filter(
      order =>
        order.status === 'planned' ||
        order.status === 'released' ||
        order.status === 'in_progress' ||
        order.status === 'completed'
    ).length
)

const receivedManufacturingOrders = computed(
  () =>
    manufacturingOrders.value.filter(
      order => order.status === 'received'
    ).length
)

const reservationRate = computed(() => {
  if (totalOnHand.value <= 0) {
    return 0
  }

  return Math.min(
    100,
    Math.round(
      (totalReserved.value / totalOnHand.value) * 100
    )
  )
})

const recentSalesOrders = computed(
  () =>
    [...salesOrders.value]
      .sort(
        (a, b) =>
          new Date(b.created_at).getTime() -
          new Date(a.created_at).getTime()
      )
      .slice(0, 5)
)

function getSalesStatusText(status: string) {
  const statusMap: Record<string, string> = {
    draft: '草稿',
    confirmed: '已确认',
  }

  return statusMap[status] ?? status
}

function getSalesStatusType(
  status: string
): TagType {
  const statusMap: Record<string, TagType> = {
    draft: 'warning',
    confirmed: 'success',
  }

  return statusMap[status] ?? 'info'
}

function formatMoney(value: number | string) {
  return Number(value).toFixed(2)
}

function formatDate(dateText: string) {
  return new Date(dateText).toLocaleString()
}

onMounted(() => {
  loadDashboard()
})
</script>

<template>
  <div class="dashboard-page">
    <div class="dashboard-hero">
      <div>
        <h1>业务概览</h1>
        <p>
          实时查看销售、库存与生产执行情况
        </p>
      </div>

      <el-button
        :icon="Refresh"
        :loading="loading"
        @click="loadDashboard"
      >
        刷新数据
      </el-button>
    </div>

    <el-alert
      v-if="errorMessage"
      :title="errorMessage"
      type="error"
      show-icon
      :closable="false"
      class="dashboard-alert"
    />

    <el-skeleton
      v-if="loading"
      :rows="6"
      animated
    />

    <template v-else>
      <div class="overview-grid">
        <el-card
          shadow="never"
          class="overview-card"
        >
          <div class="overview-card-top">
            <div
              class="overview-icon
                     overview-icon-blue"
            >
              <el-icon>
                <Document />
              </el-icon>
            </div>

            <el-tag
              type="primary"
              effect="light"
            >
              SALES
            </el-tag>
          </div>

          <div class="overview-label">
            销售订单
          </div>

          <div class="overview-value">
            {{ totalSalesOrders }}
          </div>

          <div class="overview-note">
            <span>
              草稿 {{ draftSalesOrders }}
            </span>

            <span>
              已确认 {{ confirmedSalesOrders }}
            </span>
          </div>
        </el-card>

        <el-card
          shadow="never"
          class="overview-card"
        >
          <div class="overview-card-top">
            <div
              class="overview-icon
                     overview-icon-green"
            >
              <el-icon>
                <Goods />
              </el-icon>
            </div>

            <el-tag
              type="success"
              effect="light"
            >
              STOCK
            </el-tag>
          </div>

          <div class="overview-label">
            现有库存
          </div>

          <div class="overview-value">
            {{ totalOnHand.toFixed(3) }}
          </div>

          <div class="overview-note">
            当前仓库库存总量
          </div>
        </el-card>

        <el-card
          shadow="never"
          class="overview-card"
        >
          <div class="overview-card-top">
            <div
              class="overview-icon
                     overview-icon-orange"
            >
              <el-icon>
                <Goods />
              </el-icon>
            </div>

            <el-tag
              type="warning"
              effect="light"
            >
              RESERVED
            </el-tag>
          </div>

          <div class="overview-label">
            预留库存
          </div>

          <div class="overview-value">
            {{ totalReserved.toFixed(3) }}
          </div>

          <el-progress
            :percentage="reservationRate"
            :stroke-width="7"
            :show-text="false"
            class="overview-progress"
          />

          <div class="overview-note">
            库存预留率 {{ reservationRate }}%
          </div>
        </el-card>

        <el-card
          shadow="never"
          class="overview-card"
        >
          <div class="overview-card-top">
            <div
              class="overview-icon
                     overview-icon-cyan"
            >
              <el-icon>
                <Goods />
              </el-icon>
            </div>

            <el-tag
              type="info"
              effect="light"
            >
              AVAILABLE
            </el-tag>
          </div>

          <div class="overview-label">
            可用库存
          </div>

          <div class="overview-value">
            {{ totalAvailable.toFixed(3) }}
          </div>

          <div class="overview-note">
            可供新销售订单使用
          </div>
        </el-card>

        <el-card
          shadow="never"
          class="overview-card"
        >
          <div class="overview-card-top">
            <div
              class="overview-icon
                     overview-icon-purple"
            >
              <el-icon>
                <Tickets />
              </el-icon>
            </div>

            <el-tag
              type="warning"
              effect="light"
            >
              WIP
            </el-tag>
          </div>

          <div class="overview-label">
            在制生产订单
          </div>

          <div class="overview-value">
            {{ activeManufacturingOrders }}
          </div>

          <div class="overview-note">
            计划 / 下达 / 生产 / 待入库
          </div>
        </el-card>

        <el-card
          shadow="never"
          class="overview-card"
        >
          <div class="overview-card-top">
            <div
              class="overview-icon
                     overview-icon-green"
            >
              <el-icon>
                <CircleCheck />
              </el-icon>
            </div>

            <el-tag
              type="success"
              effect="light"
            >
              RECEIVED
            </el-tag>
          </div>

          <div class="overview-label">
            已入库生产订单
          </div>

          <div class="overview-value">
            {{ receivedManufacturingOrders }}
          </div>

          <div class="overview-note">
            已完成生产并正式入库
          </div>
        </el-card>
      </div>

      <el-card
        shadow="never"
        class="recent-orders-card"
      >
        <template #header>
          <div class="section-heading">
            <div>
              <h2>最近销售订单</h2>

              <p>
                最近创建的 5 张销售订单
              </p>
            </div>

            <RouterLink
              to="/sales-orders"
              class="section-link"
            >
              查看全部
              →
            </RouterLink>
          </div>
        </template>

        <el-table
          :data="recentSalesOrders"
          stripe
          style="width: 100%"
        >
          <el-table-column
            prop="order_no"
            label="订单号"
            min-width="180"
          />

          <el-table-column
            label="总金额"
            min-width="160"
          >
            <template #default="{ row }">
              <span class="money-text">
                ¥ {{ formatMoney(row.total_amount) }}
              </span>
            </template>
          </el-table-column>

          <el-table-column
            label="状态"
            width="120"
          >
            <template #default="{ row }">
              <el-tag
                :type="
                  getSalesStatusType(row.status)
                "
                effect="light"
                round
              >
                {{
                  getSalesStatusText(
                    row.status
                  )
                }}
              </el-tag>
            </template>
          </el-table-column>

          <el-table-column
            label="创建时间"
            min-width="190"
          >
            <template #default="{ row }">
              {{
                formatDate(
                  row.created_at
                )
              }}
            </template>
          </el-table-column>
        </el-table>
      </el-card>
    </template>
  </div>
</template>