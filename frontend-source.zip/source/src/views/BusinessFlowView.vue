<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { Refresh } from '@element-plus/icons-vue'
import api from '../services/api'

interface SalesOrder { id: number; order_no: string; status: string }
interface Production { id: number; order_no: string; source_sales_order_id: number | null; product_id: number; planned_quantity: string; status: string }
interface Product { id: number; name: string; unit: string }
const router = useRouter(), sales = ref<SalesOrder[]>([]), production = ref<Production[]>([]), products = ref<Product[]>([])
const selectedId = ref<number>(), loading = ref(false), error = ref('')
const order = computed(() => sales.value.find(item => item.id === selectedId.value))
const linked = computed(() => production.value.filter(item => item.source_sales_order_id === selectedId.value))
const statusNames: Record<string, string> = { planned: '待下达', released: '已下达', in_progress: '生产中', completed: '待入库', received: '已入库' }
const productName = (id: number) => products.value.find(item => item.id === id)?.name ?? `产品 ID ${id}`
const quantity = (item: Production) => `${Number(item.planned_quantity).toLocaleString('zh-CN')} ${products.value.find(p => p.id === item.product_id)?.unit ?? ''}`
const action = computed(() => {
  if (!order.value) return { title: '先创建一张销售订单', description: '选择客户、产品、数量和单价，保存后确认订单。', path: '/sales-orders' }
  if (order.value.status === 'draft') return { title: '确认销售订单并分配库存', description: '在销售订单中选择库存分配仓库，查看已预留和缺口数量。', path: '/sales-orders' }
  if (!linked.value.length) return { title: '查看库存分配结果', description: '有缺口时生成生产订单；库存已满足时无需为了演示强行生成生产单。', path: '/sales-orders' }
  if (linked.value.some(item => item.status === 'planned')) return { title: '检查物料并下达生产', description: '在生产订单中核查物料需求，再下达生成工序；产品需有可用工艺路线。', path: '/manufacturing-orders' }
  const active = linked.value.find(item => ['released', 'in_progress'].includes(item.status))
  if (active) return { title: '按工序顺序进行报工', description: '填写操作员、合格数和不良数；前一道工序完成后再处理下一道。', path: '/mes', mo: active.id }
  if (linked.value.some(item => item.status === 'completed')) return { title: '办理生产完工入库', description: '选择入库仓库，查看库存增加及来源销售订单的自动预留结果。', path: '/manufacturing-orders' }
  return { title: '检查库存与来源流水', description: '关联生产单均已入库，可回到销售订单查看分配结果。本流程尚未包含销售发货与财务收款。', path: '/inventory-transactions' }
})
const stages = computed(() => [
  { title: '销售建单', text: '维护客户、产品及订单明细', path: '/sales-orders', done: !!order.value },
  { title: '库存分配', text: '确认订单，预留库存并识别缺口', path: '/sales-orders', done: order.value?.status === 'confirmed' },
  { title: '生产下达', text: '缺口转生产，按工艺路线生成工序', path: '/manufacturing-orders', done: !!linked.value.length && linked.value.every(item => item.status !== 'planned') },
  { title: 'MES 报工', text: '依次完成工序，保留现场报工记录', path: '/mes', done: !!linked.value.length && linked.value.every(item => ['completed', 'received'].includes(item.status)) },
  { title: '完工入库', text: '同步库存、预留与入库流水', path: '/manufacturing-orders', done: !!linked.value.length && linked.value.every(item => item.status === 'received') },
])
/** 读取现有订单状态，不通过页面点击自动推进业务。 */
async function loadData(): Promise<void> {
  loading.value = true; error.value = ''
  try {
    const [s, m, p] = await Promise.all([api.get<SalesOrder[]>('/sales-orders'), api.get<Production[]>('/manufacturing-orders'), api.get<Product[]>('/products')])
    sales.value = s.data; production.value = m.data; products.value = p.data
    if (!sales.value.some(item => item.id === selectedId.value)) selectedId.value = [...sales.value].reverse().find(item => production.value.some(mo => mo.source_sales_order_id === item.id && mo.status !== 'received'))?.id ?? sales.value.at(-1)?.id
  } catch { error.value = '业务流程加载失败，请检查服务后刷新。' }
  finally { loading.value = false }
}
/** 携带关联记录跳转，避免到 MES 后误操作其他生产单。 */
function openPage(path: string, mo?: number): void {
  const moId = mo ?? linked.value.find(item => ['released', 'in_progress'].includes(item.status))?.id ?? linked.value[0]?.id
  router.push({ path, query: path === '/sales-orders' && selectedId.value ? { order: selectedId.value } : path === '/mes' && moId ? { order: moId } : {} })
}
onMounted(loadData)
</script>

<template>
  <div class="flow-page" v-loading="loading">
    <header class="flow-header"><div><h1>业务流程</h1><p>从销售订单到完工入库，按当前进度继续演示。</p></div><el-button :icon="Refresh" :loading="loading" @click="loadData">刷新进度</el-button></header>
    <el-alert v-if="error" :title="error" type="error" :closable="false" show-icon />
    <el-card shadow="never" class="flow-selector"><label>跟踪销售订单</label><el-select v-model="selectedId" filterable placeholder="选择销售订单" aria-label="跟踪销售订单"><el-option v-for="item in sales" :key="item.id" :value="item.id" :label="item.order_no" /></el-select><el-tag v-if="order" :type="order.status === 'confirmed' ? 'success' : 'info'">{{ order.status === 'confirmed' ? '已确认' : '草稿' }}</el-tag><span>关联 {{ linked.length }} 张生产订单</span></el-card>
    <div class="flow-stages">
      <button v-for="(stage, index) in stages" :key="stage.title" class="stage" :class="{ complete: stage.done }" :disabled="!!error || loading" @click="openPage(stage.path)">
        <span class="stage-number">{{ stage.done ? '✓' : `0${index + 1}` }}</span><strong>{{ stage.title }}</strong><p>{{ stage.text }}</p><small>{{ stage.done ? '已达到此阶段' : '进入模块 →' }}</small>
      </button>
    </div>
    <section class="flow-next"><div><small>下一步建议</small><h2>{{ action.title }}</h2><p>{{ action.description }}</p></div><el-button type="primary" :disabled="!!error || loading" @click="openPage(action.path, 'mo' in action ? action.mo : undefined)">前往处理 →</el-button></section>
    <el-card shadow="never" class="flow-orders"><div class="flow-table-title"><h2>关联生产订单</h2><span>状态来自当前业务记录</span></div>
      <el-table :data="linked" stripe>
        <el-table-column prop="order_no" label="生产单号" min-width="170" /><el-table-column label="产品" min-width="200"><template #default="{ row }">{{ productName(row.product_id) }}</template></el-table-column>
        <el-table-column label="计划数量" min-width="120"><template #default="{ row }">{{ quantity(row) }}</template></el-table-column><el-table-column label="进度" min-width="120"><template #default="{ row }"><el-tag :type="row.status === 'received' ? 'success' : 'primary'">{{ statusNames[row.status] ?? row.status }}</el-tag></template></el-table-column>
        <el-table-column label="操作" min-width="200"><template #default="{ row }"><el-button link type="primary" @click="openPage('/mes', row.id)">查看工序</el-button><el-button link type="primary" @click="openPage('/manufacturing-orders')">生产与入库</el-button></template></el-table-column>
        <template #empty><el-empty description="该销售订单暂无关联生产单，可先查看库存分配结果" /></template>
      </el-table>
    </el-card>
    <footer class="flow-footer"><span>辅助准备</span><el-button @click="openPage('/boms')">BOM 物料清单</el-button><el-button @click="openPage('/routings')">工艺路线</el-button><el-button @click="openPage('/warehouses')">仓库与补料入库</el-button><el-button @click="openPage('/inventory-transactions')">库存流水</el-button></footer>
  </div>
</template>

<style scoped>
.flow-header,.flow-next,.flow-table-title{display:flex;justify-content:space-between;align-items:center;gap:20px}.flow-header{margin-bottom:20px}.flow-header h1{margin:0;font-size:28px;color:#172033}.flow-header p{margin:7px 0 0;color:#687386;font-size:14px}
.flow-selector{margin:20px 0;border-radius:12px}.flow-selector :deep(.el-card__body){display:flex;align-items:center;gap:16px;flex-wrap:wrap}.flow-selector .el-select{width:260px}.flow-selector label{font-weight:600;color:#354052}.flow-selector span{font-size:13px;color:#687386}
.flow-stages{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px}.stage{background:white;border:1px solid #e2e8f0;border-radius:12px;padding:20px;text-align:left;transition:box-shadow .15s}.stage:hover{box-shadow:0 4px 14px #20304c12}.stage-number{display:block;color:#327be4;background:#edf4ff;border-radius:10px;width:36px;height:36px;text-align:center;line-height:36px;margin-bottom:18px;font-weight:700}.stage strong{color:#172033;font-size:16px}.stage p{font-size:13px;line-height:1.8;color:#687386;min-height:46px}.stage small{color:#327be4}.stage.complete{border-color:#bce3dc}.complete .stage-number{background:#eaf7f3;color:#228f7b}.complete small{color:#228f7b}
.flow-next{padding:22px 24px;background:#edf4ff;border:1px solid #d6e4fc;border-radius:12px;margin:20px 0}.flow-next h2{font-size:20px;color:#172033;margin:8px 0}.flow-next small{color:#327be4}.flow-next p{color:#53647b;font-size:14px;margin:0;line-height:1.8}.flow-orders{border-radius:12px}.flow-table-title{margin-bottom:16px}.flow-table-title h2{font-size:18px;margin:0}.flow-table-title span{font-size:12px;color:#687386}.flow-footer{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-top:18px;color:#687386;font-size:13px}.flow-footer .el-button{margin:0}.flow-orders :deep(th.el-table__cell){background:#f5f7fb}.flow-orders :deep(td.el-table__cell){height:60px}
@media(max-width:1000px){.flow-stages{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:650px){.flow-stages{grid-template-columns:1fr}.flow-next{align-items:flex-start;flex-direction:column}}
</style>
