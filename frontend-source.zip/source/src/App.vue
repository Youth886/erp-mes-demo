<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { demoMode, resetDemo } from './demo/engine'

async function restoreDemo(): Promise<void> {
  try { await ElMessageBox.confirm('恢复这批初始演示数据？仅清除本浏览器在此演示站中的操作。', '重置演示', { confirmButtonText: '恢复初始数据', cancelButtonText: '取消' }) } catch { return }
  try { resetDemo(); location.reload() } catch { ElMessage.error('无法清除浏览器演示数据，请检查网站存储设置。') }
}

import {
  DataBoard,
  Box,
  User,
  Document,
  Goods,
  Tickets,
  Monitor,
} from '@element-plus/icons-vue'

const route = useRoute()

const pageTitle = computed(() => {
  const titleMap: Record<string, string> = {
    '/': 'Dashboard',
    '/products': '产品管理',
    '/customers': '客户管理',
    '/sales-orders': '销售订单',
    '/inventory': '库存管理',
    '/inventory-transactions': '库存流水',
    '/warehouses': '仓库与入库',
    '/business-flow': '业务流程',
    '/boms': 'BOM 物料清单',
    '/routings': '工艺路线',
    '/manufacturing-orders': '生产订单',
    '/mes': 'MES 生产执行',
  }

  return titleMap[route.path] ?? 'ERP / MES'
})
</script>

<template>
  <el-container class="erp-shell">
    <el-aside width="230px" class="erp-aside">
      <div class="brand">
        <div class="brand-mark">
          E
        </div>

        <div class="brand-text">
          <strong>ERP / MES</strong>
          <span>Manufacturing System</span>
        </div>
      </div>

      <el-menu
        :default-active="route.path"
        router
        class="erp-menu"
        background-color="#172033"
        text-color="#b9c2d0"
        active-text-color="#ffffff"
      >
        <el-menu-item index="/">
          <el-icon>
            <DataBoard />
          </el-icon>

          <span>Dashboard</span>
        </el-menu-item>

        <el-menu-item index="/business-flow">
          <el-icon><Tickets /></el-icon><span>业务流程</span>
        </el-menu-item>

        <div class="menu-group-title">
          ERP
        </div>

        <el-menu-item index="/products">
          <el-icon>
            <Box />
          </el-icon>

          <span>产品管理</span>
        </el-menu-item>

        <el-menu-item index="/customers">
          <el-icon>
            <User />
          </el-icon>

          <span>客户管理</span>
        </el-menu-item>

        <el-menu-item index="/sales-orders">
          <el-icon>
            <Document />
          </el-icon>

          <span>销售订单</span>
        </el-menu-item>

        <el-menu-item index="/inventory">
          <el-icon>
            <Goods />
          </el-icon>

          <span>库存管理</span>
        </el-menu-item>

        <el-menu-item index="/inventory-transactions">
          <el-icon><Tickets /></el-icon>
          <span>库存流水</span>
        </el-menu-item>

        <el-menu-item index="/warehouses">
          <el-icon><Box /></el-icon>
          <span>仓库与入库</span>
        </el-menu-item>

        <div class="menu-group-title">
          PRODUCTION
        </div>

        <el-menu-item index="/boms">
          <el-icon>
            <Goods />
          </el-icon>

          <span>BOM 物料清单</span>
        </el-menu-item>

        <el-menu-item index="/routings">
          <el-icon>
            <Tickets />
          </el-icon>

          <span>工艺路线</span>
        </el-menu-item>

        <el-menu-item index="/manufacturing-orders">
          <el-icon>
            <Tickets />
          </el-icon>

          <span>生产订单</span>
        </el-menu-item>

        <el-menu-item index="/mes">
          <el-icon>
            <Monitor />
          </el-icon>

          <span>MES 生产执行</span>
        </el-menu-item>
      </el-menu>

      <div class="aside-footer">
        <div class="system-dot"></div>

        <div>
          <strong>系统运行中</strong>
          <span>ERP / MES Demo</span>
        </div>
      </div>
    </el-aside>

    <el-container class="erp-right">
      <el-header class="erp-header">
        <div>
          <div class="header-title">
            {{ pageTitle }}
          </div>

          <div class="header-subtitle">
            Enterprise Resource Planning / Manufacturing Execution System
          </div>
        </div>

        <div class="header-right">
          <el-tag
            type="success"
            effect="light"
            round
          >
            {{ demoMode ? '浏览器演示' : 'API Connected' }}
          </el-tag>

          <el-button v-if="demoMode" @click="restoreDemo">重置演示</el-button>
          <div class="header-user">
            <div class="user-avatar">
              A
            </div>

            <div>
              <strong>Admin</strong>
              <span>系统管理员</span>
            </div>
          </div>
        </div>
      </el-header>

      <el-main class="erp-main">
        <RouterView />
      </el-main>
    </el-container>
  </el-container>
</template>
