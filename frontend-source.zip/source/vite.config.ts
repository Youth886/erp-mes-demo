import vue from '@vitejs/plugin-vue'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig(({ mode }) => ({
  base: mode === 'demo' ? './' : '/',
  plugins: [vue()],
  build: { outDir: mode === 'demo' ? 'dist-demo' : 'dist' },
}))
